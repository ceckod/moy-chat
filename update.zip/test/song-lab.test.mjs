import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { loadSongLab } from "./load-song-lab.mjs";

describe("SongLab — CRUD/storage слой (Фаза 1)", () => {
  test("createSong() генерира SONG-YYYY-NNNN, статус 'new', updated_at=created_at", () => {
    const { SongLab } = loadSongLab();
    const song = SongLab.createSong({ title: "Test Song", artist: "Test Artist" });
    const year = new Date().getFullYear();
    assert.match(song.id, new RegExp(`^SONG-${year}-\\d{4}$`));
    assert.equal(song.status, "new");
    assert.equal(song.analysis, null);
    assert.equal(song.created_at, song.updated_at);
  });

  test("Song ID брояч се увеличава последователно в рамките на годината", () => {
    const { SongLab } = loadSongLab();
    const a = SongLab.createSong({ title: "A" });
    const b = SongLab.createSong({ title: "B" });
    const c = SongLab.createSong({ title: "C" });
    const nums = [a, b, c].map(s => parseInt(s.id.split("-")[2], 10));
    assert.deepEqual(nums, [nums[0], nums[0] + 1, nums[0] + 2]);
  });

  test("list() връща най-новия запис отгоре", async () => {
    const { SongLab } = loadSongLab();
    const first = SongLab.createSong({ title: "First" });
    await new Promise(r => setTimeout(r, 5)); // гарантира различен created_at от бързото synchronous изпълнение
    const second = SongLab.createSong({ title: "Second" });
    const list = SongLab.list();
    assert.equal(list[0].id, second.id);
    assert.equal(list[1].id, first.id);
  });

  test("update() прави частична промяна и обновява updated_at, без да пипа created_at", async () => {
    const { SongLab } = loadSongLab();
    const song = SongLab.createSong({ title: "Original" });
    await new Promise(r => setTimeout(r, 5));
    const updated = SongLab.update(song.id, { title: "Renamed" });
    assert.equal(updated.title, "Renamed");
    assert.equal(updated.created_at, song.created_at);
    assert.ok(updated.updated_at >= song.created_at);
  });

  test("remove() трайно изтрива записа", () => {
    const { SongLab } = loadSongLab();
    const song = SongLab.createSong({ title: "ToDelete" });
    assert.ok(SongLab.get(song.id));
    SongLab.remove(song.id);
    assert.equal(SongLab.get(song.id), null);
  });

  test("get() за несъществуващ id връща null, не хвърля грешка", () => {
    const { SongLab } = loadSongLab();
    assert.equal(SongLab.get("SONG-9999-9999"), null);
  });

  test("две различни SongLab зареждания (различен localStorage stub) не си пречат — изолация между тестове", () => {
    const { SongLab: labA } = loadSongLab();
    const { SongLab: labB } = loadSongLab();
    labA.createSong({ title: "Само в А" });
    assert.equal(labA.list().length, 1);
    assert.equal(labB.list().length, 0);
  });

  test("повредени данни в localStorage → празен списък, не срив (виж _readAll try/catch)", () => {
    const store = new Map([["songlab_projects_v1", "{невалиден json"]]);
    const localStorageStub = {
      getItem: (k) => (store.has(k) ? store.get(k) : null),
      setItem: (k, v) => store.set(k, String(v)),
      removeItem: (k) => store.delete(k),
    };
    const { SongLab } = loadSongLab({ localStorage: localStorageStub });
    assert.equal(SongLab.list().length, 0);
  });
});

describe("SongLab.AGENT_ROLES — структурен интегритет (Фаза 3)", () => {
  test("точно 13-те роли от master спецификацията присъстват, с уникални id-та", () => {
    const { SongLab } = loadSongLab();
    const expectedIds = [
      "audio_analyst", "hook_analyst", "market_analyst", "positioning_agent",
      "youtube_strategist", "tiktok_strategist", "visual_director",
      "shortform_director", "hook_evolution", "metadata_seo",
      "ghost_audience", "red_team", "final_judge",
    ];
    const actualIds = SongLab.AGENT_ROLES.map(r => r.id);
    assert.equal(actualIds.length, 13);
    assert.deepEqual([...actualIds].sort(), [...expectedIds].sort());
    assert.equal(new Set(actualIds).size, 13, "няма дублирани id-та");
  });

  test("всяка роля има непразна инструкция и валиден schema string", () => {
    const { SongLab } = loadSongLab();
    for (const role of SongLab.AGENT_ROLES) {
      assert.ok(role.name && role.name.length > 0, `${role.id}: липсва name`);
      assert.ok(role.instruction && role.instruction.length > 10, `${role.id}: инструкцията е твърде къса/липсва`);
      assert.ok(role.schema && role.schema.trim().startsWith("{"), `${role.id}: schema не изглежда като JSON обект описание`);
    }
  });

  test("само final_judge носи usesAllAgents:true (синтезира останалите)", () => {
    const { SongLab } = loadSongLab();
    const flagged = SongLab.AGENT_ROLES.filter(r => r.usesAllAgents);
    assert.equal(flagged.length, 1);
    assert.equal(flagged[0].id, "final_judge");
  });

  test("_agentRole() намира роля по id, връща null за непозната", () => {
    const { SongLab } = loadSongLab();
    assert.equal(SongLab._agentRole("hook_analyst").id, "hook_analyst");
    assert.equal(SongLab._agentRole("не_съществува"), null);
  });
});

describe("SongLab.analyzeSong() — Фаза 2, текстов режим (без реално аудио в сесията)", () => {
  test("успешен AI отговор → status 'analyzed', структуриран analysis, method 'text'", async () => {
    const fakeAnalysis = { genre: "pop", mood: "upbeat", overall_score: 72 };
    const { SongLab } = loadSongLab({
      callAI: async () => JSON.stringify(fakeAnalysis),
    });
    const song = SongLab.createSong({ title: "Test" });
    await SongLab.analyzeSong(song.id);
    const result = SongLab.get(song.id);
    assert.equal(result.status, "analyzed");
    assert.equal(result.analysis.method, "text");
    assert.equal(result.analysis.overall_score, 72);
  });

  test("AI грешка → status 'analysis_failed', НЕ 'analyzed' с измислени данни", async () => {
    const { SongLab } = loadSongLab({
      callAI: async () => { throw new Error("мрежата отказа"); },
    });
    const song = SongLab.createSong({ title: "Test" });
    await SongLab.analyzeSong(song.id);
    const result = SongLab.get(song.id);
    assert.equal(result.status, "analysis_failed");
    assert.equal(result.analysis, null);
  });
});
