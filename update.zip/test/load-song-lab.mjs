import fs from "node:fs";
import vm from "node:vm";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SONG_LAB_JS_PATH = path.join(__dirname, "..", "js", "song-lab.js");

/**
 * Зарежда js/song-lab.js БЕЗ да го променя — изпълнява оригиналния текст
 * на файла във vm контекст (същия подход като load-niche-scoring.mjs), за
 * да достъпим SongLab за тестове точно както браузърът би го видял.
 *
 * song-lab.js очаква няколко глобални неща от останалия сайт:
 *   - localStorage         — реален в браузъра; тук минимален in-memory stub
 *   - toast(msg)            — UI известия, опционален (typeof проверка в кода)
 *   - callAI/callGeminiMultimodal/extractJson/fileToBase64 — реални мрежови/AI
 *     helper-и от providers/*; тук се подават като stub-ове по подразбиране,
 *     за да могат тестовете да мокват AI отговора без реална мрежа.
 *
 * Връща { SongLab, sandbox } — sandbox позволява на тест да презапише
 * localStorage/callAI/... между отделни извиквания (мокване), без да
 * пипа истинския репо файл.
 */
export function loadSongLab(overrides = {}) {
  const code = fs.readFileSync(SONG_LAB_JS_PATH, "utf8");

  const store = new Map();
  const localStorageStub = {
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => { store.set(k, String(v)); },
    removeItem: (k) => { store.delete(k); },
    clear: () => { store.clear(); },
  };

  const documentStub = { getElementById: () => null };

  const sandbox = {
    console,
    module: { exports: {} },
    document: overrides.document || documentStub,
    confirm: overrides.confirm || (() => true),
    localStorage: overrides.localStorage || localStorageStub,
    toast: overrides.toast || (() => {}),
    callAI: overrides.callAI || (async () => { throw new Error("callAI stub не е мокнат за този тест"); }),
    callGeminiMultimodal: overrides.callGeminiMultimodal || (async () => { throw new Error("callGeminiMultimodal stub не е мокнат за този тест"); }),
    extractJson: overrides.extractJson || ((raw) => JSON.parse(raw)),
    fileToBase64: overrides.fileToBase64 || (async () => "stub-base64"),
  };
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { filename: SONG_LAB_JS_PATH });
  const SongLab = sandbox.module.exports.SongLab || sandbox.SongLab;
  return { SongLab, sandbox };
}
