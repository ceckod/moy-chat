#!/usr/bin/env node
/* =========================================================
   system-check.js — статичен диагностичен инструмент за целия проект.
   Пуска се с: node system-check.js
   Без npm зависимости (само вграден Node.js). Нищо не променя в
   проекта — само чете файлове и пише лог.

   Какво проверява:
   1) Синтаксис на всеки .js/.mjs файл (node --check).
   2) Валидност на всеки .json файл (JSON.parse).
   3) Всеки <script src="..."> в .html файловете сочи ли към
      съществуващ локален файл.
   4) Всеки onclick="Namespace.method(...)" в .html сочи ли към метод,
      който РЕАЛНО съществува в някой от <script>-овете, заредени от
      СЪЩАТА html страница (хваща точно бъга, който вече поправихме —
      функция, дефинирана в mъртъв, незареждан файл).
   5) "Мъртви" JS файлове — файлове с еднакво име в различни папки,
      от които само единият се зарежда от HTML (дублиращи се файлове
      са чест източник на "поправих го, но нищо не се промени").
   6) Прости run-time capture тестове за ключовите data/*.json файлове
      (валиден масив/обект, не е празен низ и т.н.).

   Изходът е едновременно в конзолата (цветно) и в system-check-log.txt
   (обикновен текст, за да можеш да го пратиш/прочетеш после).
   ========================================================= */

const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const ROOT = __dirname;
const IGNORE_DIRS = new Set([
  "node_modules", ".git", "incoming", "drafts", ".github"
]);

const C = {
  reset: "\x1b[0m", red: "\x1b[31m", green: "\x1b[32m",
  yellow: "\x1b[33m", cyan: "\x1b[36m", bold: "\x1b[1m", gray: "\x1b[90m"
};

const logLines = [];
function say(msg, color) {
  const plain = msg.replace(/\x1b\[[0-9;]*m/g, "");
  logLines.push(plain);
  console.log(color ? color + msg + C.reset : msg);
}
function section(title) {
  say("");
  say("── " + title + " " + "─".repeat(Math.max(0, 60 - title.length)), C.bold + C.cyan);
}

const issues = [];   // { level: 'error'|'warn', where, msg }
function err(where, msg) { issues.push({ level: "error", where, msg }); say(`  ❌ ${where} — ${msg}`, C.red); }
function warn(where, msg) { issues.push({ level: "warn", where, msg }); say(`  ⚠️  ${where} — ${msg}`, C.yellow); }
function ok(msg) { say(`  ✅ ${msg}`, C.green); }

// ---------------------------------------------------------------------
// Помощни функции за обхождане на файловата система
// ---------------------------------------------------------------------
function walk(dir, exts, out = []) {
  for (const name of fs.readdirSync(dir)) {
    if (IGNORE_DIRS.has(name)) continue;
    const full = path.join(dir, name);
    const stat = fs.statSync(full);
    if (stat.isDirectory()) walk(full, exts, out);
    else if (exts.some(e => name.endsWith(e))) out.push(full);
  }
  return out;
}
function rel(p) { return path.relative(ROOT, p).replace(/\\/g, "/"); }

// ---------------------------------------------------------------------
// 1) Синтаксис на JS/MJS файлове
// ---------------------------------------------------------------------
section("1) Синтаксис на JS/MJS файлове");
const jsFiles = walk(ROOT, [".js", ".mjs"]);
let jsOkCount = 0;
for (const f of jsFiles) {
  try {
    execFileSync(process.execPath, ["--check", f], { stdio: "pipe" });
    jsOkCount++;
  } catch (e) {
    const msg = (e.stderr ? e.stderr.toString() : e.message).split("\n").slice(0, 3).join(" | ");
    err(rel(f), "синтактична грешка — " + msg);
  }
}
ok(`${jsOkCount}/${jsFiles.length} JS/MJS файла без синтактични грешки.`);

// ---------------------------------------------------------------------
// 2) Валидност на JSON файлове
// ---------------------------------------------------------------------
section("2) Валидност на JSON файлове");
const jsonFiles = walk(ROOT, [".json"]);
let jsonOkCount = 0;
for (const f of jsonFiles) {
  try {
    const text = fs.readFileSync(f, "utf8");
    if (text.trim()) JSON.parse(text);
    jsonOkCount++;
  } catch (e) {
    err(rel(f), "невалиден JSON — " + e.message);
  }
}
ok(`${jsonOkCount}/${jsonFiles.length} JSON файла са валидни.`);

// ---------------------------------------------------------------------
// 3) + 4) HTML: <script src> съществуват ли, onclick методите съществуват ли
// ---------------------------------------------------------------------
section("3) HTML → <script src=\"...\"> сочат ли към съществуващи файлове");
const htmlFiles = walk(ROOT, [".html"]);
const htmlScriptMap = {}; // html file -> [resolved js file paths that loaded fine]

for (const f of htmlFiles) {
  const html = fs.readFileSync(f, "utf8");
  const scriptSrcs = [...html.matchAll(/<script[^>]*\ssrc=["']([^"']+)["']/gi)].map(m => m[1]);
  const localScripts = [];
  for (const src of scriptSrcs) {
    if (/^https?:\/\//i.test(src) || src.startsWith("//")) continue; // външен CDN, пропускаме
    const resolved = path.resolve(path.dirname(f), src);
    if (!fs.existsSync(resolved)) {
      err(rel(f), `<script src="${src}"> — файлът не съществува`);
    } else {
      localScripts.push(resolved);
    }
  }
  htmlScriptMap[f] = localScripts;
  if (scriptSrcs.length) ok(`${rel(f)}: ${localScripts.length}/${scriptSrcs.length} локални script src OK.`);
}

section("4) HTML → onclick=\"Namespace.method(...)\" сочи ли към реално съществуващ метод");
for (const f of htmlFiles) {
  const html = fs.readFileSync(f, "utf8");
  const calls = [...html.matchAll(/onclick=["'][^"']*?([A-Z][A-Za-z0-9_]*)\.([a-zA-Z_$][A-Za-z0-9_$]*)\s*\(/g)];
  if (!calls.length) continue;
  // Обединяваме съдържанието на всички <script src> файлове, заредени от тази страница,
  // плюс инлайн <script>...</script> блокове в самата страница.
  const loadedFiles = htmlScriptMap[f] || [];
  let combinedSrc = loadedFiles.map(p => { try { return fs.readFileSync(p, "utf8"); } catch { return ""; } }).join("\n");
  combinedSrc += [...html.matchAll(/<script(?![^>]*\ssrc=)[^>]*>([\s\S]*?)<\/script>/gi)].map(m => m[1]).join("\n");

  const seen = new Set();
  for (const m of calls) {
    const [, ns, method] = m;
    const key = ns + "." + method;
    if (seen.has(key)) continue;
    seen.add(key);
    // Търсим дефиниция във формат "method(" (function shorthand в обект) или "method:" (свойство функция)
    const defRe = new RegExp(`(^|[\\s,{])${method}\\s*(\\(|:\\s*(async\\s*)?function|:\\s*(async\\s*)?\\()`, "m");
    const nsDeclared = new RegExp(`(const|let|var)\\s+${ns}\\s*=`).test(combinedSrc) || new RegExp(`window\\.${ns}\\s*=`).test(combinedSrc);
    if (!nsDeclared) {
      warn(rel(f), `onclick вика "${key}(...)" но не намирам обект/namespace "${ns}" в заредените script-ове (може да идва от друг файл, който не съм проследил — провери ръчно).`);
      continue;
    }
    if (!defRe.test(combinedSrc)) {
      err(rel(f), `onclick вика "${key}(...)" но методът "${method}" НЕ Е намерен в нито един script, зареден от тази страница — бутонът вероятно е "мъртъв".`);
    }
  }
}
ok("Проверката на onclick handler-и приключи (виж ❌/⚠️ по-горе за конкретни находки).");

// ---------------------------------------------------------------------
// 5) Дублирани имена на JS файлове — потенциално "сенчести" мъртви копия
// ---------------------------------------------------------------------
section("5) Дублирани имена на JS файлове (риск от объркване кой файл реално се зарежда)");
const byBasename = {};
for (const f of jsFiles) {
  const base = path.basename(f);
  (byBasename[base] = byBasename[base] || []).push(f);
}
const allLoadedJs = new Set(Object.values(htmlScriptMap).flat().map(p => path.resolve(p)));
let dupWarnings = 0;
for (const [base, files] of Object.entries(byBasename)) {
  if (files.length < 2) continue;
  const loaded = files.filter(f => allLoadedJs.has(path.resolve(f)));
  const notLoaded = files.filter(f => !allLoadedJs.has(path.resolve(f)));
  if (loaded.length && notLoaded.length) {
    dupWarnings++;
    warn(
      "дублиран файл",
      `"${base}" съществува на ${files.length} места: ЗАРЕЖДА СЕ → ${loaded.map(rel).join(", ")} | НЕ СЕ зарежда от нито едно HTML → ${notLoaded.map(rel).join(", ")}. ` +
      `Ако редактираш незаредения файл, промените НЯМА да се отразят никъде — точно това причини предишния счупен бутон.`
    );
  }
}
if (!dupWarnings) ok("Няма открити дублирани JS имена с рискова комбинация зареден/незареден.");

// ---------------------------------------------------------------------
// 6) Базова проверка на data/*.json — очакван тип (масив/обект) и не е празен
// ---------------------------------------------------------------------
section("6) data/*.json — базова проверка на формата");
const dataDir = path.join(ROOT, "data");
if (fs.existsSync(dataDir)) {
  for (const name of fs.readdirSync(dataDir)) {
    if (!name.endsWith(".json")) continue;
    const f = path.join(dataDir, name);
    try {
      const parsed = JSON.parse(fs.readFileSync(f, "utf8") || "null");
      if (parsed === null) warn(rel(f), "файлът е празен/null — може да е очаквано, ако още няма данни.");
      else ok(`${rel(f)}: ${Array.isArray(parsed) ? `масив с ${parsed.length} елемента` : `обект с ${Object.keys(parsed).length} ключа`}.`);
    } catch (e) {
      err(rel(f), "не може да се прочете като JSON — " + e.message);
    }
  }
} else {
  warn("data/", "папката не съществува.");
}

// ---------------------------------------------------------------------
// Обобщение
// ---------------------------------------------------------------------
section("Обобщение");
const errors = issues.filter(i => i.level === "error");
const warnings = issues.filter(i => i.level === "warn");
say(`${errors.length} грешки, ${warnings.length} предупреждения.`, errors.length ? C.red + C.bold : C.green + C.bold);
if (!errors.length && !warnings.length) say("Системата изглежда чиста ✅", C.green);

const outPath = path.join(ROOT, "system-check-log.txt");
fs.writeFileSync(outPath, `CDB Dashboard — system check\n${new Date().toISOString()}\n\n` + logLines.join("\n") + "\n");
console.log(`\n${C.gray}Пълният лог е записан в: ${rel(outPath)}${C.reset}`);

// ---------------------------------------------------------------------
// Manifest за браузърната версия (секция "🩺 Диагностика на кода" в сайта).
// Браузърът няма достъп до файловата система (директория листинг), затова
// диагностиката там чете този json списък и след това fetch-ва всеки файл.
// Пускай "node system-check.js" пак всеки път след добавяне/трене на файлове,
// за да остане списъкът верен.
// ---------------------------------------------------------------------
const manifestPath = path.join(ROOT, "data", "system-check-manifest.json");
try {
  fs.mkdirSync(path.dirname(manifestPath), { recursive: true });
  fs.writeFileSync(manifestPath, JSON.stringify({
    generatedAt: new Date().toISOString(),
    jsFiles: jsFiles.map(rel).sort(),
    jsonFiles: jsonFiles.map(rel).sort(),
    htmlFiles: htmlFiles.map(rel).sort()
  }, null, 2));
  console.log(`${C.gray}Manifest за уеб диагностиката обновен: ${rel(manifestPath)}${C.reset}`);
} catch (e) {
  console.log(`${C.yellow}⚠️ Не успях да запиша manifest-а (${e.message}) — уеб секцията ще ползва старата версия, ако има.${C.reset}`);
}

process.exitCode = errors.length ? 1 : 0;
