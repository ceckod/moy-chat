# CDB Dashboard – DistroKid HyperFollow Bridge

DistroKid does not expose the user's My Music / HyperFollow catalog as a public API. This companion Chrome/Edge MV3 extension therefore uses the browser session the user already logged into.

## Install
1. Open `chrome://extensions` (or Edge `edge://extensions`).
2. Enable **Developer mode**.
3. Choose **Load unpacked**.
4. Select this `distrokid-bridge` folder.
5. Open DistroKid and log in normally.
6. In CDB Dashboard → Shorts Studio → DistroKid library press **🔐 Влез в DistroKid и извлечи ВСИЧКИ HyperFollow**.

The extension never reads or transmits the password, cookies, or DistroKid session tokens. It only asks the already-open DistroKid tab for visible HyperFollow URLs and returns those URLs to the dashboard in the same browser.
