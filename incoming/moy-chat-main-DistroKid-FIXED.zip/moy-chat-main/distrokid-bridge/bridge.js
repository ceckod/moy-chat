(function () {
  const DK_HOSTS = new Set(['distrokid.com','www.distrokid.com']);
  const isDK = DK_HOSTS.has(location.hostname);

  function decodeSlug(s) {
    try { return decodeURIComponent(s).replace(/[-_]+/g,' ').replace(/\s+/g,' ').trim(); } catch { return s; }
  }

  function extract() {
    const map = new Map();
    const anchors = [...document.querySelectorAll('a[href]')];
    for (const a of anchors) {
      let u;
      try { u = new URL(a.href, location.href); } catch { continue; }
      const path = u.pathname;
      if (!/\/hyperfollow\//i.test(path)) continue;
      const parts = path.split('/').filter(Boolean);
      const i = parts.findIndex(x => x.toLowerCase() === 'hyperfollow');
      if (i < 0 || !parts[i+1]) continue;
      const artist = decodeSlug(parts[i+1]);
      const title = parts[i+2] ? decodeSlug(parts[i+2]) : (a.textContent || '').trim();
      const key = u.origin + path;
      let parentText = '';
      let el = a;
      for (let n=0; n<4 && el; n++, el=el.parentElement) {
        const t = (el.innerText || '').replace(/\s+/g,' ').trim();
        if (t.length > parentText.length && t.length < 800) parentText = t;
      }
      map.set(key, { artist, song: title || parentText || artist, url: u.href, username: artist, context: parentText });
    }
    return [...map.values()];
  }

  async function extractWithScroll() {
    // HyperFollow dashboard may lazy-load cards. Scroll a little, without clicking
    // anything or changing account state, then scan the final DOM.
    if (isDK) {
      for (let i=0; i<8; i++) {
        window.scrollTo(0, document.documentElement.scrollHeight);
        await new Promise(r => setTimeout(r, 350));
      }
      window.scrollTo(0,0);
    }
    return extract();
  }

  if (isDK) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg || msg.type !== 'CDB_DK_EXTRACT') return;
      extractWithScroll().then(entries => {
        sendResponse({ ok:true, entries, source: location.href });
      }).catch(e => sendResponse({ ok:false, error:e.message || 'Неуспешно извличане.' }));
      return true;
    });
  }

  // On the user's dashboard, act as a tiny page<->extension bridge.
  window.addEventListener('message', ev => {
    if (ev.source !== window || !ev.data || ev.data.type !== 'CDB_DK_GET_LIBRARY') return;
    chrome.runtime.sendMessage({ type:'CDB_DK_GET_LIBRARY', requestId: ev.data.requestId }, result => {
      const payload = result || { ok:false, error: chrome.runtime.lastError?.message || 'Extension error' };
      window.postMessage({ type:'CDB_DK_LIBRARY_RESULT', requestId: ev.data.requestId, ...payload }, '*');
    });
  });
})();
