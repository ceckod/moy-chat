const CDB_SITE_REQUEST = 'CDB_DK_GET_LIBRARY';

function isDistroKid(url='') {
  try { return new URL(url).hostname === 'distrokid.com' || new URL(url).hostname === 'www.distrokid.com'; }
  catch { return false; }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== CDB_SITE_REQUEST) return;
  chrome.tabs.query({}, tabs => {
    const dk = tabs.find(t => isDistroKid(t.url));
    if (!dk?.id) {
      sendResponse({ ok:false, error:'Няма отворен DistroKid таб. Отвори DistroKid, логни се и остави таба отворен.' });
      return;
    }
    chrome.tabs.sendMessage(dk.id, { type:'CDB_DK_EXTRACT', requestId: msg.requestId }, response => {
      if (chrome.runtime.lastError || !response) {
        sendResponse({ ok:false, error:'DistroKid табът не отговори. Презареди страницата след login и опитай отново.' });
        return;
      }
      if (!response.ok) { sendResponse(response); return; }
      sendResponse(response);
    });
  });
  return true;
});
