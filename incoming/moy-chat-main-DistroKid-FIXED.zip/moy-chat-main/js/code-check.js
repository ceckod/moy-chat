/* =========================================================
   CODE CHECK — уеб версия на system-check.js (виж корена на проекта).
   Разлика от "🧪 Системен тест" (SystemTest): онзи тества РЪНТАЙМ
   поведение (localStorage, ключове, мрежа...) на текущата сесия.
   Този модул прави СТАТИЧЕН анализ на кода/файловете, за да хване
   счупени неща ПРЕДИ да са гръмнали в ръцете на потребителя —
   синтактични грешки, невалиден JSON, счупени <script src>,
   onclick бутони сочещи към несъществуващ метод, и "мъртви" дублирани
   JS файлове (точно това счупи DistroKid бутона преди — виж коментара
   по-долу).

   Чете data/system-check-manifest.json (генериран от "node
   system-check.js" в корена — пусни го пак locally след добавяне/
   триене на файлове, за да остане списъкът верен) и после fetch-ва
   всеки файл, за да провери съдържанието му. Работи само когато
   сайтът се сервира по http(s) (GitHub Pages и т.н.) — при отваряне
   direktно от диска (file://) браузърът обикновено блокира fetch към
   други локални файлове.
   ========================================================= */
const CodeCheck = {
  _lastResults: null,

  _esc(s) {
    const d = document.createElement("div");
    d.textContent = s == null ? "" : String(s);
    return d.innerHTML;
  },

  _row(level, where, msg) {
    return { level, where, msg };
  },

  log(container, text, cls) {
    if (!container) return;
    const time = new Date().toLocaleTimeString("bg-BG");
    container.innerHTML += `<div class="${cls || ""}">[${time}] ${this._esc(text)}</div>`;
    container.scrollTop = container.scrollHeight;
  },

  async run() {
    const out = document.getElementById("codeCheckOut");
    const summaryEl = document.getElementById("codeCheckSummary");
    if (!out) return;
    out.innerHTML = "";
    if (summaryEl) summaryEl.innerHTML = "";
    const results = [];
    const push = (level, where, msg) => {
      results.push(this._row(level, where, msg));
      const cls = level === "error" ? "muted" : level === "warn" ? "muted" : "muted";
      const icon = level === "error" ? "❌" : level === "warn" ? "⚠️" : level === "ok" ? "✅" : "ℹ️";
      this.log(out, `${icon} ${where ? where + " — " : ""}${msg}`);
    };

    push("info", "", "🩺 Стартирам диагностика на кода...");

    let manifest;
    try {
      const res = await fetch("data/system-check-manifest.json", { cache: "no-store" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      manifest = await res.json();
    } catch (e) {
      push("error", "manifest", "Не успях да заредя data/system-check-manifest.json (" + e.message + "). Пусни \"node system-check.js\" в корена на проекта, за да го генерира, и се увери, че сайтът се отваря през http(s), не directno от диска.");
      this._renderSummary(results);
      this._lastResults = results;
      return;
    }
    push("info", "", `Manifest от ${new Date(manifest.generatedAt).toLocaleString("bg-BG")} — ${manifest.jsFiles.length} JS, ${manifest.jsonFiles.length} JSON, ${manifest.htmlFiles.length} HTML файла.`);

    // ---------------------------------------------------------------
    // 1) JSON валидност
    // ---------------------------------------------------------------
    push("info", "", "── 1) Валидност на JSON файлове ──");
    let jsonOk = 0;
    for (const f of manifest.jsonFiles) {
      try {
        const res = await fetch(f, { cache: "no-store" });
        if (!res.ok) { push("error", f, "не се зарежда — HTTP " + res.status); continue; }
        const text = await res.text();
        if (text.trim()) JSON.parse(text);
        jsonOk++;
      } catch (e) {
        push("error", f, "невалиден JSON — " + e.message);
      }
    }
    push("ok", "", `${jsonOk}/${manifest.jsonFiles.length} JSON файла са валидни.`);

    // ---------------------------------------------------------------
    // 2) JS синтаксис (само класически .js — .mjs ES модули не могат
    //    да се синтактично проверят без изпълнение чрез new Function,
    //    защото import/export не са позволени в тяло на функция).
    // ---------------------------------------------------------------
    push("info", "", "── 2) Синтаксис на JS файлове ──");
    let jsOk = 0, jsSkipped = 0;
    for (const f of manifest.jsFiles) {
      if (f.endsWith(".mjs")) { jsSkipped++; continue; }
      try {
        const res = await fetch(f, { cache: "no-store" });
        if (!res.ok) { push("error", f, "не се зарежда — HTTP " + res.status); continue; }
        const text = await res.text();
        // new Function само КОМПИЛИРА тялото (никога не го изпълнява,
        // защото функцията не се извиква след това) — безопасно е за
        // проверка на синтаксис без странични ефекти.
        new Function(text);
        jsOk++;
      } catch (e) {
        if (e instanceof SyntaxError) push("error", f, "синтактична грешка — " + e.message);
        // Други грешки (напр. "Unexpected token 'export'" за файлове,
        // писани като модул без .mjs разширение) също се показват, но
        // маркирани по-меко, защото може да е нарочен ES module синтаксис.
        else push("warn", f, "new Function() отказа да компилира (може да е нарочен ES module синтаксис) — " + e.message);
      }
    }
    push("ok", "", `${jsOk}/${manifest.jsFiles.length - jsSkipped} проверени .js файла без синтактични грешки (${jsSkipped} .mjs файла пропуснати — ES модули, виж бележката горе).`);

    // ---------------------------------------------------------------
    // 3) HTML → <script src> сочат ли към съществуващи файлове
    // ---------------------------------------------------------------
    push("info", "", "── 3) HTML → &lt;script src&gt; съществуват ли ──");
    const htmlScriptSrcs = {}; // html path -> [local script src paths]
    for (const f of manifest.htmlFiles) {
      try {
        const res = await fetch(f, { cache: "no-store" });
        if (!res.ok) { push("error", f, "html файлът не се зарежда — HTTP " + res.status); continue; }
        const html = await res.text();
        const srcs = [...html.matchAll(/<script[^>]*\ssrc=["']([^"']+)["']/gi)].map(m => m[1]);
        const local = [];
        for (const src of srcs) {
          if (/^https?:\/\//i.test(src) || src.startsWith("//")) continue;
          const resolved = new URL(src, new URL(f, location.href)).pathname;
          try {
            const r2 = await fetch(resolved, { method: "HEAD", cache: "no-store" });
            if (!r2.ok) push("error", f, `<script src="${src}"> → HTTP ${r2.status}`);
            else local.push(resolved);
          } catch (e) {
            push("error", f, `<script src="${src}"> — грешка при проверка (${e.message})`);
          }
        }
        htmlScriptSrcs[f] = { html, local };
      } catch (e) {
        push("error", f, "грешка при четене — " + e.message);
      }
    }
    push("ok", "", "Проверката на <script src=\"...\"> приключи.");

    // ---------------------------------------------------------------
    // 4) onclick="Namespace.method(...)" — за ТЕКУЩАТА страница (index.html)
    //    правим ТОЧНА проверка срещу реално заредените в момента обекти
    //    (window[ns][method]) — най-силната проверка, защото не гадае.
    //    За другите html файлове (ai.html, aichat.html...) правим същата
    //    heuristic текстова проверка като CLI версията.
    // ---------------------------------------------------------------
    push("info", "", "── 4) onclick методи съществуват ли ──");
    let onclickChecked = 0, onclickBroken = 0;
    const currentPath = location.pathname.split("/").pop() || "index.html";
    for (const [f, data] of Object.entries(htmlScriptSrcs)) {
      const isCurrent = f === currentPath || (currentPath === "" && f === "index.html");
      const calls = [...data.html.matchAll(/onclick=["'][^"']*?([A-Z][A-Za-z0-9_]*)\.([a-zA-Z_$][A-Za-z0-9_$]*)\s*\(/g)];
      if (!calls.length) continue;
      const seen = new Set();
      let combinedSrc = "";
      if (!isCurrent) {
        for (const p of data.local) {
          try { const r = await fetch(p, { cache: "no-store" }); combinedSrc += await r.text() + "\n"; } catch (e) { /* игнорираме */ }
        }
      }
      for (const m of calls) {
        const [, ns, method] = m;
        const key = ns + "." + method;
        if (seen.has(key)) continue;
        seen.add(key);
        onclickChecked++;
        if (isCurrent) {
          // Точна проверка — обектите вече са заредени в текущия прозорец.
          const obj = window[ns];
          if (obj === undefined) { push("error", f, `onclick вика "${key}(...)" но "${ns}" не съществува като глобален обект в момента.`); onclickBroken++; }
          else if (typeof obj[method] !== "function") { push("error", f, `onclick вика "${key}(...)" но "${ns}.${method}" НЕ Е функция (бутонът е "мъртъв").`); onclickBroken++; }
        } else {
          const defRe = new RegExp(`(^|[\\s,{])${method}\\s*(\\(|:\\s*(async\\s*)?function|:\\s*(async\\s*)?\\()`, "m");
          const nsDeclared = new RegExp(`(const|let|var)\\s+${ns}\\s*=`).test(combinedSrc) || new RegExp(`window\\.${ns}\\s*=`).test(combinedSrc);
          if (!nsDeclared) push("warn", f, `onclick вика "${key}(...)" — не намирам "${ns}" в скриптовете на тази страница (провери ръчно).`);
          else if (!defRe.test(combinedSrc)) { push("error", f, `onclick вика "${key}(...)" но методът "${method}" не е намерен — вероятно "мъртъв" бутон.`); onclickBroken++; }
        }
      }
    }
    push("ok", "", `Проверени ${onclickChecked} уникални onclick извиквания, ${onclickBroken} изглеждат счупени.`);

    // ---------------------------------------------------------------
    // 5) Дублирани JS имена — кой реално се зарежда на ТЕКУЩАТА страница
    // ---------------------------------------------------------------
    push("info", "", "── 5) Дублирани JS файлове ──");
    const loadedOnThisPage = new Set([...document.querySelectorAll("script[src]")].map(s => new URL(s.getAttribute("src"), location.href).pathname));
    const byBase = {};
    for (const f of manifest.jsFiles) {
      const base = f.split("/").pop();
      (byBase[base] = byBase[base] || []).push(f);
    }
    let dupCount = 0;
    for (const [base, files] of Object.entries(byBase)) {
      if (files.length < 2) continue;
      const abs = files.map(f => new URL(f, location.href).pathname);
      const loaded = files.filter((f, i) => loadedOnThisPage.has(abs[i]));
      const notLoaded = files.filter((f, i) => !loadedOnThisPage.has(abs[i]));
      if (loaded.length && notLoaded.length) {
        dupCount++;
        push("warn", "дублиран файл", `"${base}" на ${files.length} места: зарежда се → ${loaded.join(", ")} | НЕ се зарежда → ${notLoaded.join(", ")}. Редакция в незаредения файл никога няма да се отрази никъде.`);
      }
    }
    push("ok", "", dupCount ? `${dupCount} рискови дублирания — виж ⚠️ по-горе.` : "Няма открити рискови дублирания на тази страница.");

    push("info", "", "🎉 Диагностиката приключи.");
    this._renderSummary(results);
    this._lastResults = results;
  },

  _renderSummary(results) {
    const summaryEl = document.getElementById("codeCheckSummary");
    if (!summaryEl) return;
    const errors = results.filter(r => r.level === "error").length;
    const warns = results.filter(r => r.level === "warn").length;
    const color = errors ? "#e5484d" : warns ? "#f5a623" : "#3ecf8e";
    summaryEl.innerHTML = `<strong style="color:${color};">${errors} грешки, ${warns} предупреждения.</strong>`;
  },

  copyLog() {
    const out = document.getElementById("codeCheckOut");
    if (!out) return;
    const text = out.innerText || "";
    navigator.clipboard.writeText(text)
      .then(() => toast("📋 Логът е копиран ✅"))
      .catch(() => toast("⚠️ Неуспешно копиране — браузърът отказа достъп до clipboard"));
  },

  downloadLog() {
    const out = document.getElementById("codeCheckOut");
    if (!out) return toast("Няма лог още — пусни проверката първо");
    const text = `CDB Dashboard — code check\n${new Date().toISOString()}\n\n` + (out.innerText || "");
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "code-check-log.txt";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
};
