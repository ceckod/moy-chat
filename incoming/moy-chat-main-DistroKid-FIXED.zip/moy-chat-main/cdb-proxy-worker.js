/* =========================================================
   CDB Dashboard — собствен CORS proxy (Cloudflare Worker).
   Виж README.md → "CORS Proxy (по избор)" за стъпки по инсталация.

   Защо ти трябва: без това, дашбордът пада към безплатна публична
   CORS прокси услуга (CodeTabs, api.codetabs.com) — тя има твърд лимит
   ~5 заявки/сек и понякога е бавна/нестабилна, защото я ползват хиляди
   непознати сайтове едновременно. Собствен Worker е:
   - Безплатен (Cloudflare Free tier — 100,000 заявки/ден, повече от
     достатъчно за едно табло).
   - Само твой — няма чужд трафик да те бави или да те баннат заедно
     с други, злоупотребяващи сайтове.
   - Без лимит от 5 заявки/сек.

   Формат: приема ?target=ORIGINAL_URL (encodeURIComponent-нат) и
   препраща заявката 1:1 (метод, хедъри, тяло) към нея, после връща
   отговора обратно с добавени CORS хедъри, за да го приеме браузърът.

   Инсталация (5 мин, виж README.md за подробности):
   1. dash.cloudflare.com → Workers & Pages → Create → "Hello World".
   2. Edit code → изтрий всичко → постави ТОЗИ файл → Deploy.
   3. Копирай URL-а (https://твоя-worker.workers.dev) → в дашборда:
      Настройки → Proxy & Мрежа → Proxy URL → Запази.
   ========================================================= */

// По избор — ограничи до кои домейни Worker-ът въобще ще проксира,
// за да не се превърне в отворен прокси за произволен трафик. Празен
// масив = разрешава всичко (най-простото, но по-малко предпазливо).
// За да ограничиш: ['distrokid.com', 'hyperfollow.com', 'spotify.com', ...]
const ALLOWED_HOST_SUFFIXES = [];

function isAllowedHost(hostname) {
  if (!ALLOWED_HOST_SUFFIXES.length) return true;
  return ALLOWED_HOST_SUFFIXES.some(suf => hostname === suf || hostname.endsWith("." + suf));
}

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Max-Age": "86400"
};

export default {
  async fetch(request) {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }

    const reqUrl = new URL(request.url);
    const target = reqUrl.searchParams.get("target");
    if (!target) {
      return new Response(
        JSON.stringify({ error: "Липсва ?target=ORIGINAL_URL параметър." }),
        { status: 400, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
      );
    }

    let targetUrl;
    try {
      targetUrl = new URL(target);
    } catch (e) {
      return new Response(
        JSON.stringify({ error: "Невалиден target URL." }),
        { status: 400, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
      );
    }
    if (!["http:", "https:"].includes(targetUrl.protocol) || !isAllowedHost(targetUrl.hostname)) {
      return new Response(
        JSON.stringify({ error: "Този домейн не е разрешен." }),
        { status: 403, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
      );
    }

    // Препращаме метод/хедъри/тяло 1:1 — само махаме хедъри, които биха
    // издали/объркали реалния произход (Host, Origin, Cookie не се пипат
    // от заявки на дашборда, но ги чистим за всеки случай).
    const outHeaders = new Headers(request.headers);
    outHeaders.delete("host");
    outHeaders.delete("origin");
    outHeaders.delete("cookie");

    const init = { method: request.method, headers: outHeaders, redirect: "follow" };
    if (!["GET", "HEAD"].includes(request.method)) {
      init.body = await request.arrayBuffer();
    }

    let upstream;
    try {
      upstream = await fetch(targetUrl.toString(), init);
    } catch (e) {
      return new Response(
        JSON.stringify({ error: "Целевият сървър не отговори: " + e.message }),
        { status: 502, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
      );
    }

    const respHeaders = new Headers(upstream.headers);
    for (const [k, v] of Object.entries(CORS_HEADERS)) respHeaders.set(k, v);
    // Не препращаме хедъри, които биха объркали браузъра при cross-origin четене.
    respHeaders.delete("content-security-policy");
    respHeaders.delete("x-frame-options");

    return new Response(upstream.body, { status: upstream.status, headers: respHeaders });
  }
};
