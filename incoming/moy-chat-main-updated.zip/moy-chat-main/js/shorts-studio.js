/* =========================================================
   Header коментар (виж ARCHITECTURE.md, "Правила за бъдеща работа" т.3):
   Зависимости (всички runtime, вътре в методи):
   fileToBase64(), callGeminiMultimodal(), callAI(), extractJson(),
   toast(), guardClick() (само от index.html onclick), Step4.uploadVideo()
   (само от uploadAll — не пипа Step4, само го извиква), AppState (по избор,
   за да прочете текущото име на песента от активния проект).
   Кой го ползва: само index.html (view-shorts-studio, бутони + input-и).
   Собствен namespace — не пипа app.js/QuickUpload/Step4 отвътре, само
   извиква публичните им методи.
   ========================================================= */
/* =========================================================
   AI SHORTS STUDIO — "качи 1 песен → получи N различни Shorts,
   готови за YouTube"
   Pipeline: аудио → (Gemini, multimodal) анализ + избор на N различни
   "hook" момента (timestamp диапазони) → (Claude) уникално заглавие/
   описание/хаштагове за всеки момент → визуализаторът (собствен скрит
   iframe, презарежда се за всеки клип) изрязва точно този диапазон
   във вертикално (9:16) видео → преглед/редакция → 1 бутон качва
   всички последователно в YouTube (unlisted, като останалата част
   от dashboard-а).

   Линкове за стрийминг (Spotify/Apple Music/DistroKid) в описанието:
   AI-ят НИКОГА не измисля URL — генерира описанието с литерални токени
   ({{SPOTIFY_LINK}} и т.н.), а findLinks()/_injectLinks() ги заменят
   ДЕТЕРМИНИРАНО с реални стойности (или трият целия ред, ако линкът е
   празен). Spotify/Apple Music се търсят автоматично (Spotify през
   NicheToolkit._getSpotifyToken(), Apple през публичния iTunes Search
   API) — DistroKid няма публичен search, остава ръчно поле.
   ========================================================= */
const DISTROKID_LINKS_WORKFLOW_FILE = "distrokid-links.yml";

const ShortsStudio = {
  audioFile: null,
  items: [],          // [{ index, start, end, hookReason, hookText, title, description, tags, videoBlob, fileName, status }]
  analysis: null,      // {genre, mood, energy, language, language_code, lyrics}
  _msgBound: false,
  _renderQueueBusy: false,

  // Локален GET-only CORS прокси fallback — САМО за findLinks()/enrichLibrary()
  // в този файл (четене на HyperFollow страница + Spotify/iTunes search, и
  // трите винаги GET). Общото proxied() в js/network.js нарочно вече НЕ прави
  // автоматичен fallback (виж коментара там) — премахнато на 2026-09-04, защото
  // старата публична CodeTabs прокси поддържа само GET, а AI provider-ите
  // (Gemini/Claude/OpenRouter) викат POST през същата функция, което висеше
  // безкрайно ("чакам отговор, няма такъв" в AI Чат/Системен тест). Тук obаче
  // ВСИЧКИ извиквания са GET, затова е безопасно да ползваме публични прокси
  // локално, без да пипаме споделения proxied() и без риск да върнем AI бъга.
  // Ако потребителят е задал собствен Proxy URL в Настройки, той си остава
  // с приоритет (същото поведение като преди).
  //
  // Fix (2026-09-05): CodeTabs се оказа ненадежден при 30+ последователни
  // заявки в enrichLibrary() — виси до timeout (15с) на ВСЯКА песен, вместо
  // да върне грешка веднага, което правеше цялата библиотека непроходима
  // (37 песни × 15с = >9 минути и нищо намерено). Затова вместо един-
  // единствен прокси, пробваме списък поредно и връщаме първия успешен —
  // виж _proxyCandidates()/_fetchViaProxies() по-долу (замести старото
  // еднократно _getProxied(), премахнато като станало неизползвано).
  //
  // Списък прокси кандидати, пробвани ПОРЕДНО, докато един не отговори
  // успешно. Собственият Proxy URL от Настройки (ако е зададен) винаги е
  // пръв. CodeTabs е втори (както досега), allorigins.win — резервен трети,
  // за случаите в които CodeTabs виси/е претоварен.
  _proxyCandidates(url) {
    const k = Keys.load();
    const list = [];
    if (k.proxyUrl) list.push(`${k.proxyUrl}?target=${encodeURIComponent(url)}`);
    list.push(`https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}`);
    list.push(`https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`);
    return list;
  },

  // Пробва прокситата от _proxyCandidates() едно по едно, с по-КРАТЪК
  // timeout за всеки опит (по подразбиране 9с, не 15с) — за да не се чака
  // 15с × 3 прокситата (45с) за всяка от 37-те песни, ако първото откаже
  // бързо. Връща първия успешен (res.ok) отговор. Ако всички откажат,
  // хвърля грешката от ПОСЛЕДНИЯ опит нагоре — извикващият код я логва.
  async _fetchViaProxies(url, options = {}, msPerTry = 9000) {
    const candidates = this._proxyCandidates(url);
    let lastErr = null;
    for (const proxyUrl of candidates) {
      try {
        const res = await fetchTimeout(proxyUrl, options, msPerTry);
        if (res.ok) return res;
        lastErr = new Error(`HTTP ${res.status}`);
      } catch (e) {
        lastErr = e;
      }
    }
    throw lastErr || new Error("Всички прокситата отказаха");
  },

  onAudioSelected(input) {
    const f = input.files[0];
    const infoEl = document.getElementById("ssAudioInfo");
    if (!f) { if (infoEl) infoEl.textContent = ""; this.audioFile = null; return; }
    this.audioFile = f;
    if (infoEl) infoEl.textContent = `Избрано: ${f.name} (${Math.round(f.size / 1024 / 1024 * 10) / 10} MB)`;
    const nameEl = document.getElementById("ssSongName");
    if (nameEl && !nameEl.value.trim()) {
      nameEl.value = f.name.replace(/\.[^/.]+$/, "").replace(/[_\-]+/g, " ").trim();
    }
    const artistEl = document.getElementById("ssArtistName");
    const savedArtist = localStorage.getItem("cdb_artist_name_v1");
    if (artistEl && !artistEl.value.trim() && savedArtist) artistEl.value = savedArtist;
    this._loadSavedLinks();
    document.getElementById("ssStartBtn").disabled = false;
  },

  saveArtistName(v) { if (v && v.trim()) localStorage.setItem("cdb_artist_name_v1", v.trim()); },

  // --- DistroKid библиотека (пейстнат списък от "My Music") -------------
  // Всяка песен в DistroKid си има СОБСТВЕНА HyperFollow страница (различна
  // от общата hyperfollow.com/{юзърнейм}) — затова пазим целия списък
  // {artist, song, url}, вместо да гадаем 1 общ линк за всички клипове.
  importDistrokidLibrary() {
    const raw = document.getElementById("ssDistrokidLibraryPaste")?.value || "";
    const entries = this._parseDistrokidLibrary(raw);
    const statusEl = document.getElementById("ssDistrokidLibStatus");
    if (!entries.length) {
      if (statusEl) statusEl.textContent = "⚠️ Не намерих нито един разпознаваем ред (заглавие + hyperfollow линк). Провери формата на пейстнатия текст.";
      return;
    }
    try { localStorage.setItem("cdb_distrokid_library_v1", JSON.stringify(entries)); } catch (e) { /* тихо, не е фатално */ }
    // Ако юзърнеймът все още е празен, вземаме го от библиотеката (удобство).
    const hfEl = document.getElementById("ssHyperfollowUsername");
    if (hfEl && !hfEl.value.trim() && entries[0].username) {
      hfEl.value = entries[0].username;
      localStorage.setItem("cdb_hyperfollow_username_v1", entries[0].username);
    }
    if (statusEl) statusEl.textContent = `✅ Импортирани ${entries.length} песни. При "Опитай да намеря..." ще пасва точния линк по име на песента.`;
    this.log(`📥 Импортирана DistroKid библиотека: ${entries.length} песни.`);
    this.renderSavedLibrary();
  },

  // Показва ЗАПАЗЕНАТА библиотека (localStorage, cdb_distrokid_library_v1)
  // веднага при отваряне на раздела — не само по време на активно
  // enrichLibrary() изпълнение (виж Nav.showView(\"shorts-studio\") хук в
  // js/nav.js). Данните вече се пазят автоматично в localStorage при всеки
  // import/enrich; тази функция само ги ПОКАЗВА, без да прави нови мрежови
  // заявки — затова е безопасно да се вика при всяко влизане в раздела.
  renderSavedLibrary() {
    const lib = this._loadDistrokidLibrary();
    const resultsEl = document.getElementById("ssLibEnrichResults");
    const statusEl = document.getElementById("ssLibEnrichStatus");
    if (!resultsEl) return;
    if (!lib.length) { resultsEl.innerHTML = ""; if (statusEl) statusEl.textContent = ""; return; }
    const enrichedCount = lib.filter(e => e.platforms && Object.keys(e.platforms).length).length;
    resultsEl.innerHTML = lib.map((e, i) => this._enrichRowHtml(e, i)).join("");
    if (statusEl) statusEl.textContent = `📚 Запазена библиотека: ${lib.length} песни (${enrichedCount} с намерени линкове). Записана е локално в този браузър — за архив/друго устройство ползвай "⬇️ Изтегли библиотеката (JSON)" по-долу.`;
  },

  // Сваля цялата запазена библиотека (заглавия + hyperfollow линкове +
  // всички намерени платформени линкове) като .json файл. localStorage е
  // ВРЪЗАН само с този конкретен браузър/устройство — ако потребителят
  // изчисти кеша, смени браузър/устройство, или ползва приложението и от
  // телефон, и от компютър, данните НЕ се пренасят автоматично. Файлът е
  // за архив и за ръчно пренасяне (пейстни го обратно през "Импортирай
  // ръчно намерени линкове (JSON)" по-горе, или направо в localStorage).
  downloadLibraryJson() {
    const lib = this._loadDistrokidLibrary();
    if (!lib.length) return toast("Библиотеката е празна — първо импортирай списъка от DistroKid.");
    const blob = new Blob([JSON.stringify(lib, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const stamp = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `distrokid-library-${stamp}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    this.log(`⬇️ Изтеглена библиотека (${lib.length} песни) като distrokid-library-${stamp}.json`);
  },

  // --- Трайно запазване на библиотеката в GitHub repo-то -----------------
  // localStorage е вързан само с този браузър/устройство — за да оцелее
  // трайно между сесии/устройства (и да не се загуби при изчистен кеш),
  // библиотеката се commit-ва в data/distrokid-library.json през СЪЩИЯ
  // GitHub Contents API механизъм, който вече ползват SystemUpdate/
  // YouTubeDiscovery/MetadataOptimizer (Keys.load().ghToken/ghOwner/ghRepo/
  // ghBranch — вече съществуващи полета в Настройки, нищо ново за
  // конфигуриране). Repo-то е публично, затова ЧЕТЕНЕТО минава през
  // безплатния raw.githubusercontent.com (без token) — само ЗАПИСВАНЕТО
  // минава през api.github.com с token (нужен е "Contents: Read and write").
  _GH_LIBRARY_API_PATH(k) {
    return `https://api.github.com/repos/${k.ghOwner}/${k.ghRepo}/contents/data/distrokid-library.json`;
  },

  async saveLibraryToGitHub() {
    const lib = this._loadDistrokidLibrary();
    if (!lib.length) return toast("Библиотеката е празна — първо импортирай списъка от DistroKid.");
    const k = Keys.load();
    if (!k.ghToken) return toast("❌ Липсва GitHub Token — виж Настройки → API Ключове");
    if (!k.ghOwner || !k.ghRepo) return toast("❌ Липсват GitHub потребител/организация или repo — виж Настройки → YouTube Тракер (същите полета)");
    const branch = k.ghBranch || "main";
    const path = this._GH_LIBRARY_API_PATH(k);
    const statusEl = document.getElementById("ssLibGithubStatus");
    if (statusEl) statusEl.textContent = "⏳ Запазвам в repo-то...";
    try {
      // sha е нужен само ако файлът вече съществува (update); при първия
      // запис (404) просто продължаваме без sha — GitHub го създава направо.
      let sha = null;
      const shaRes = await fetchTimeout(`${path}?ref=${encodeURIComponent(branch)}`, {
        headers: { "Authorization": `Bearer ${k.ghToken}`, "Accept": "application/vnd.github+json" }
      }, 15000);
      if (shaRes.ok) { sha = (await shaRes.json()).sha; }
      else if (shaRes.status !== 404) { throw new Error(`Не мога да прочета текущия файл (${shaRes.status})`); }

      const content = btoa(unescape(encodeURIComponent(JSON.stringify(lib, null, 2) + "\n")));
      const body = { message: `🎞️ Shorts Studio: DistroKid библиотека — ${lib.length} песни`, content, branch };
      if (sha) body.sha = sha;
      const putRes = await fetchTimeout(path, {
        method: "PUT",
        headers: { "Authorization": `Bearer ${k.ghToken}`, "Accept": "application/vnd.github+json", "Content-Type": "application/json" },
        body: JSON.stringify(body)
      }, 20000);
      if (!putRes.ok) throw new Error(`GitHub ${putRes.status}: ${(await putRes.text()).slice(0, 300)}`);

      if (statusEl) statusEl.textContent = `✅ Запазено трайно в repo-то: data/distrokid-library.json (${lib.length} песни).`;
      this.log(`💾 DistroKid библиотека (${lib.length} песни) записана трайно в GitHub repo-то (data/distrokid-library.json).`);
      toast("✅ Запазено в repo-то");
    } catch (e) {
      if (statusEl) statusEl.textContent = `❌ ${e.message}`;
      toast("❌ " + e.message);
    }
  },

  // Зарежда последната запазена версия от repo-то (напр. на друго
  // устройство/браузър, или след изчистен кеш/преинсталация) — през
  // публичния raw.githubusercontent.com, без нужда от token за самото
  // четене (repo-то е публично).
  async loadLibraryFromGitHub() {
    const k = Keys.load();
    if (!k.ghOwner || !k.ghRepo) return toast("❌ Липсват GitHub потребител/организация или repo — виж Настройки → YouTube Тракер");
    const branch = k.ghBranch || "main";
    const statusEl = document.getElementById("ssLibGithubStatus");
    if (statusEl) statusEl.textContent = "⏳ Зареждам от repo-то...";
    try {
      const url = `https://raw.githubusercontent.com/${k.ghOwner}/${k.ghRepo}/${branch}/data/distrokid-library.json?t=${Date.now()}`;
      const res = await fetchTimeout(url, {}, 15000);
      if (res.status === 404) {
        if (statusEl) statusEl.textContent = "⚪ В repo-то още няма запазена библиотека (нормално, ако е първият запис).";
        return;
      }
      if (!res.ok) throw new Error(`GitHub ${res.status}`);
      const lib = await res.json();
      localStorage.setItem("cdb_distrokid_library_v1", JSON.stringify(lib));
      this.renderSavedLibrary();
      if (statusEl) statusEl.textContent = `✅ Заредени ${lib.length} песни от repo-то.`;
      this.log(`📥 DistroKid библиотека (${lib.length} песни) заредена от GitHub repo-то (data/distrokid-library.json).`);
    } catch (e) {
      if (statusEl) statusEl.textContent = `❌ ${e.message}`;
      toast("❌ " + e.message);
    }
  },

  // Тригва .github/workflows/distrokid-links.yml — сървърно (GitHub Actions
  // runner) обхождане на ВСИЧКИ HyperFollow страници от библиотеката,
  // директна HTTP заявка, БЕЗ браузър, БЕЗ CORS, БЕЗ прокси нужда изобщо
  // (за разлика от enrichLibrary() тук в браузъра, който заради CORS
  // задължително минава през публични прокси — виж _proxyCandidates()).
  // ВАЖНО: workflow-ът чете data/distrokid-library.json ОТ repo-то, не от
  // localStorage — затова изисква да си натиснал "💾 Запази трайно" ПОНЕ
  // ВЕДНЪЖ преди първото сканиране, иначе скриптът не намира какво да
  // обходи. Резултатът се commit-ва обратно автоматично; след ~1-2 мин
  // (виж линка към Actions в статуса) натисни "📥 Зареди последно
  // запазеното от repo-то", за да видиш новите линкове тук в dashboard-а.
  async dispatchLibraryScan() {
    const k = Keys.load();
    if (!k.ghToken) return toast("❌ Липсва GitHub Token — виж Настройки → API Ключове");
    if (!k.ghOwner || !k.ghRepo) return toast("❌ Липсват GitHub потребител/организация или repo — виж Настройки → YouTube Тракер");
    const branch = k.ghBranch || "main";
    const statusEl = document.getElementById("ssLibGithubStatus");
    if (statusEl) statusEl.textContent = "⏳ Тригвам сканиране в GitHub Actions...";
    try {
      const res = await fetchTimeout(
        `https://api.github.com/repos/${k.ghOwner}/${k.ghRepo}/actions/workflows/${DISTROKID_LINKS_WORKFLOW_FILE}/dispatches`,
        {
          method: "POST",
          headers: { "Authorization": `Bearer ${k.ghToken}`, "Accept": "application/vnd.github+json", "Content-Type": "application/json" },
          body: JSON.stringify({ ref: branch })
        }, 20000
      );
      if (!res.ok) throw new Error(`GitHub ${res.status}: ${(await res.text()).slice(0, 300)}`);
      if (statusEl) {
        statusEl.innerHTML = `▶️ Сканирането е стартирано в GitHub Actions — отнема обикновено 1-2 мин. ` +
          `<a href="https://github.com/${k.ghOwner}/${k.ghRepo}/actions" target="_blank" rel="noopener">Виж прогреса →</a> ` +
          `После натисни "📥 Зареди последно запазеното от repo-то".`;
      }
      toast("▶️ Сканирането стартирано в GitHub Actions");
      this.log(`▶️ DistroKid library scan (${DISTROKID_LINKS_WORKFLOW_FILE}) тригнат в GitHub Actions.`);
    } catch (e) {
      if (statusEl) statusEl.textContent = `❌ ${e.message}`;
      toast("❌ " + e.message);
    }
  },

  _loadDistrokidLibrary() {
    try { return JSON.parse(localStorage.getItem("cdb_distrokid_library_v1") || "[]"); }
    catch (e) { return []; }
  },

  // Минава през ЦЯЛАТА импортирана DistroKid библиотека (не само текущата
  // песен). Приоритет 1: чете директно HyperFollow страницата на всяка
  // песен (entry.url) и извлича ВСИЧКИ вградени платформени линкове наведнъж
  // (Spotify/Apple/Deezer/Tidal/iHeart/... — виж _PLATFORM_PATTERNS) —
  // гарантирано точна песен, без риск от грешно съвпадение. Приоритет 2
  // (fallback само за платформи, които страницата НЕ съдържа): Spotify Web
  // API / iTunes Search API / YouTube Data API търсене по име. Резултатите
  // се записват обратно в библиотеката (localStorage), за да не се търсят
  // повторно следващия път.
  //
  // Fix (2026-09-05): песни, за които вече имаме и трите основни линка
  // (Spotify + Apple Music + YouTube), се ПРОПУСКАТ изцяло на следващо
  // изпълнение — нито страницата им се чете пак, нито се пращат нови
  // Spotify/iTunes/YouTube заявки. Преди това всяко "🔍 Намери..." минаваше
  // през ВСИЧКИ 37 песни отново дори за вече напълно готовите, което хабеше
  // време и API квоти без причина. За песни, при които липсва само ЕДНА
  // платформа (напр. има YouTube, няма Spotify), логиката по-долу и без това
  // вече търсеше само липсващото (виж `if (!e.platforms.spotify ...)` и
  // т.н.) — сега това е вярно и на ниво цяла песен, не само на ниво платформа.
  async enrichLibrary() {
    const lib = this._loadDistrokidLibrary();
    if (!lib.length) return toast("Първо импортирай DistroKid библиотеката по-горе");
    const statusEl = document.getElementById("ssLibEnrichStatus");
    const resultsEl = document.getElementById("ssLibEnrichResults");
    resultsEl.innerHTML = "";
    const total = lib.length;
    const CORE_PLATFORMS = ["spotify", "apple", "youtube"];
    let skipped = 0;

    let spotifyToken = null;
    try { spotifyToken = await NicheToolkit._getSpotifyToken(); }
    catch (e) { this.log("⚠️ Spotify token: " + e.message + " — Spotify fallback търсенето няма да работи (страницата пак може да го намери)."); }
    const ytKey = Keys.load().ytApiKey;
    if (!ytKey) this.log("⚪ Няма YouTube API Key в Настройки — YouTube fallback търсенето е изключено (страницата пак може да съдържа YouTube линк).");

    for (let i = 0; i < total; i++) {
      const e = lib[i];
      e.platforms = e.platforms || {};

      // Вече имаме и трите основни линка за тази песен — нищо ново да се
      // намери от повторно четене/търсене, пропускаме я директно.
      if (CORE_PLATFORMS.every(key => e.platforms[key])) {
        skipped++;
        if (statusEl) statusEl.textContent = `⏭️ ${i + 1}/${total}: ${e.song} — вече готова (Spotify+Apple+YouTube), пропускам.`;
        resultsEl.innerHTML += this._enrichRowHtml(e, i);
        resultsEl.scrollTop = resultsEl.scrollHeight;
        continue;
      }

      if (statusEl) statusEl.textContent = `⏳ ${i + 1}/${total}: ${e.song}...`;

      // Приоритет 1 — четем реалната HyperFollow страница на песента.
      if (e.url) {
        const found = await this._fetchPlatformLinksFromPage(e.url);
        Object.assign(e.platforms, found); // не трием вече намерени от преди, само допълваме
      }

      // Приоритет 2 — fallback търсене по име, само за платформи, които
      // страницата не съдържаше.
      if (!e.platforms.spotify && spotifyToken) {
        try {
          const q = `track:${e.song} artist:${e.artist}`;
          const res = await this._fetchViaProxies(`https://api.spotify.com/v1/search?q=${encodeURIComponent(q)}&type=track&limit=1`, {
            headers: { "Authorization": `Bearer ${spotifyToken}` }
          }, 9000);
          if (res.ok) { const d = await res.json(); const u = d.tracks?.items?.[0]?.external_urls?.spotify; if (u) e.platforms.spotify = u; }
        } catch (err) { /* тихо — просто оставаме без Spotify за тази песен */ }
      }
      // Търсим и когато Apple линкът вече е намерен от HyperFollow страницата
      // (Приоритет 1) — тогава пропускаме само трайно вече намереното
      // (previewAudio/coverArt), защото ТЕЗИ полета не идват от страницата,
      // а само от този iTunes Search резултат (нужни са на 🎬 AI Shorts Pro
      // бутона по-долу, виж js/shorts-pro-render.js).
      if (!e.platforms.apple || !e.previewAudio || !e.coverArt) {
        try {
          const term = `${e.artist} ${e.song}`;
          const res = await this._fetchViaProxies(`https://itunes.apple.com/search?term=${encodeURIComponent(term)}&entity=song&limit=1`, {}, 9000);
          if (res.ok) {
            const d = await res.json();
            const r0 = d.results?.[0];
            if (r0?.trackViewUrl) e.platforms.apple = r0.trackViewUrl;
            // previewUrl — 30-сек AAC preview, публичен URL, точно каквото
            // трябва на render-pro-short.yml като audio_url (виж
            // scripts/render_short_ffmpeg.py — сваля го директно с requests).
            if (r0?.previewUrl) e.previewAudio = r0.previewUrl;
            // artworkUrl100 е малка (100x100) — upgrade-ваме резолюцията със
            // същия трик като scripts/_pick_next_song.py (pick_cover_url).
            if (r0?.artworkUrl100) e.coverArt = r0.artworkUrl100.replace("100x100bb", "1200x1200bb");
          }
        } catch (err) { /* тихо */ }
      }
      if (!e.platforms.youtube && ytKey) {
        try {
          const q = `${e.artist} ${e.song}`;
          const res = await fetchTimeout(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=${encodeURIComponent(q)}&key=${ytKey}`, {}, 15000);
          if (res.ok) {
            const d = await res.json();
            const vid = d.items?.[0]?.id?.videoId;
            if (vid) e.platforms.youtube = `https://www.youtube.com/watch?v=${vid}`;
          }
        } catch (err) { /* тихо */ }
      }

      // Обратна съвместимост с по-стари полета, ако другаде в кода/данните
      // все още се четат директно (напр. стар импорт от преди тази версия).
      e.spotifyUrl = e.platforms.spotify || e.spotifyUrl || "";
      e.appleUrl = e.platforms.apple || e.appleUrl || "";
      e.youtubeUrl = e.platforms.youtube || e.youtubeUrl || "";

      resultsEl.innerHTML += this._enrichRowHtml(e, i);
      resultsEl.scrollTop = resultsEl.scrollHeight;
      // Кратка пауза между песните — по-щадящо към API квотите.
      await new Promise(r => setTimeout(r, 300));
    }

    try { localStorage.setItem("cdb_distrokid_library_v1", JSON.stringify(lib)); } catch (err) { /* не е фатално */ }
    const counts = {};
    for (const key of Object.keys(this._PLATFORM_LABELS)) counts[key] = lib.filter(e => e.platforms?.[key]).length;
    const summary = Object.entries(counts).filter(([, n]) => n > 0).map(([k, n]) => `${this._platformLabel(k)} ${n}/${total}`).join(" · ");
    const skippedNote = skipped ? ` (${skipped} песни вече бяха готови и бяха пропуснати)` : "";
    if (statusEl) statusEl.textContent = `✅ Готово: ${summary || "нищо не се намери"}${skippedNote}.`;
    this.log(`🔍 Обогатяване на библиотеката готово — ${summary || "нищо не се намери"}${skippedNote}.`);
  },

  _enrichRowHtml(e, i) {
    const platforms = e.platforms || {};
    const chips = Object.keys(this._PLATFORM_LABELS)
      .filter(key => platforms[key])
      .map(key => `<a href="${this._escAttr(platforms[key])}" target="_blank" rel="noopener">${this._platformLabel(key)} ✅</a>`)
      .join(" · ");
    // 🎬 AI Shorts Pro — тригва server-side render-pro-short.yml (виж
    // js/shorts-pro-render.js) за ТАЗИ конкретна песен. Активен само след
    // като previewAudio/coverArt са намерени (идват от iTunes Search в
    // enrichLibrary() по-горе) — без тях dispatch()-ът така или иначе би
    // отказал с ясна грешка, но е по-ясно за потребителя бутонът просто да
    // е disabled, вместо да кликне и да получи toast с обяснение.
    const canRender = !!(e.previewAudio && e.coverArt);
    const renderBtn = typeof i === "number"
      ? `<button class="btn ghost" style="margin-top:4px;" ${canRender ? "" : "disabled title=\"Първо: 🔍 Намери Spotify + Apple Music + YouTube — трябва Apple Music резултат за preview аудио + обложка\""} onclick="guardClick(this, () => ShortsStudio.dispatchProRender(${i}))">🎬 AI Shorts Pro рендер</button>`
      : "";
    return `<div style="padding:6px 0;border-bottom:1px solid var(--border);">
      <strong>${this._esc(e.song)}</strong><br>
      ${chips || '<span class="muted">— нищо намерено —</span>'}<br>
      ${renderBtn}
    </div>`;
  },

  // Тригва js/shorts-pro-render.js (ShortsProRender.dispatch) за песента на
  // индекс i от запазената DistroKid библиотека. Самият dispatch() си блокира
  // (await) до завършен run и сваля резултата — тук само подготвяме entry-то
  // и логваме резултата; guardClick() (в onclick-а на бутона в _enrichRowHtml)
  // се грижи бутонът да е disabled по време на изчакването.
  async dispatchProRender(i) {
    const lib = this._loadDistrokidLibrary();
    const e = lib[i];
    if (!e) return toast("❌ Не намерих тази песен в библиотеката — презареди страницата и опитай пак.");
    if (!e.previewAudio || !e.coverArt) {
      return toast('❌ Липсва preview аудио или обложка за тази песен — първо пусни "🔍 Намери Spotify + Apple Music + YouTube".', 6000);
    }
    if (typeof ShortsProRender === "undefined") {
      return toast("❌ js/shorts-pro-render.js не е зареден — провери index.html.");
    }
    this.log(`🎬 AI Shorts Pro: тригвам server-side рендер за "${e.song}"...`);
    const result = await ShortsProRender.dispatch({
      song: e.song,
      artist: e.artist,
      audio_url: e.previewAudio,
      cover_url: e.coverArt,
    });
    if (result && result.ok && result.downloaded) {
      this.log(`✅ AI Shorts Pro: "${e.song}" — видеото е свалено (.zip).`);
    } else if (result && result.ok) {
      this.log(`⚠️ AI Shorts Pro: "${e.song}" — рендерът мина, но свалянето трябва да е ръчно (виж toast-а).`);
    } else if (result) {
      this.log(`❌ AI Shorts Pro: "${e.song}" — рендерът се провали (виж toast-а).`);
    } else {
      this.log(`❌ AI Shorts Pro: "${e.song}" — dispatch-ът не завърши успешно (виж toast-а).`);
    }
  },

  _parseDistrokidLibrary(text) {
    const NOISE = /^(©|English|Help|Support Center|Company|DistroKid Blog|Nail Clippers|Artists For Change|Careers|Influencer|Product|Plans|Bandzoogle|Instant Share|Mixea|DistroVid|HyperFollow|Direct|Mobile App|DistroKid for|Privacy policy|Cookie|Terms of use|Sitemap|Distribution agreement|Upload|My Music|Stats|Splits|Upgrade|Bank|HyperFollow is the easiest)/i;
    const lines = text.split(/\r?\n/).map(l => l.trim());
    const entries = [];
    let lastTitleLine = null;
    for (const line of lines) {
      if (!line) continue;
      const urlMatch = line.match(/^https?:\/\/distrokid\.com\/hyperfollow\/([^/\s]+)\/(\S+)$/i);
      if (urlMatch) {
        if (lastTitleLine) {
          const dashIdx = lastTitleLine.indexOf(" - ");
          const artist = dashIdx >= 0 ? lastTitleLine.slice(0, dashIdx).trim() : "";
          const song = dashIdx >= 0 ? lastTitleLine.slice(dashIdx + 3).trim() : lastTitleLine;
          entries.push({ artist, song, username: urlMatch[1], url: line });
        }
        lastTitleLine = null;
        continue;
      }
      if (/\d+\s*views?|presave/i.test(line)) continue; // статистика реда - прескачаме
      if (NOISE.test(line)) continue; // навигация/футър шум от копирания текст
      lastTitleLine = line; // кандидат за "Артист - Заглавие" реда
    }
    return entries;
  },

  // Нормализира заглавие за сравнение: маха (feat. ...), пунктуация, регистър.
  _normalizeSongTitle(s) {
    return (s || "").toString().toLowerCase()
      .replace(/\(feat\.[^)]*\)/gi, "")
      .replace(/feat\.[^-]*$/gi, "")
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .trim();
  },

  // Намира най-доброто съвпадение в библиотеката по име на текущата песен.
  // Връща {artist, song, username, url} или null.
  _findDistrokidLink(songName) {
    const lib = this._loadDistrokidLibrary();
    const target = this._normalizeSongTitle(songName);
    if (!target || !lib.length) return null;
    for (const e of lib) { if (this._normalizeSongTitle(e.song) === target) return e; } // точно съвпадение
    for (const e of lib) { // частично съвпадение като резервен вариант
      const norm = this._normalizeSongTitle(e.song);
      if (norm && (norm.includes(target) || target.includes(norm))) return e;
    }
    return null;
  },

  // Линковете се пазят локално по (артист + песен), за да не търсиш наново
  // всеки път — веднъж намерени/въведени, автоматично се презареждат.
  _linksKey() {
    const song = (document.getElementById("ssSongName")?.value || "").trim().toLowerCase();
    const artist = (document.getElementById("ssArtistName")?.value || "").trim().toLowerCase();
    return `${artist}::${song}`;
  },
  _loadSavedLinks() {
    try {
      const all = JSON.parse(localStorage.getItem("cdb_song_links_v1") || "{}");
      const saved = all[this._linksKey()];
      if (saved) {
        if (saved.spotify) document.getElementById("ssLinkSpotify").value = saved.spotify;
        if (saved.apple) document.getElementById("ssLinkApple").value = saved.apple;
        if (saved.distrokid) document.getElementById("ssLinkDistrokid").value = saved.distrokid;
      }
      const hfEl = document.getElementById("ssHyperfollowUsername");
      const savedHf = localStorage.getItem("cdb_hyperfollow_username_v1");
      if (hfEl && !hfEl.value.trim() && savedHf) hfEl.value = savedHf;
    } catch (e) { /* без localStorage — просто не предпълваме, не е фатално */ }
  },
  _saveLinks() {
    try {
      const all = JSON.parse(localStorage.getItem("cdb_song_links_v1") || "{}");
      all[this._linksKey()] = {
        spotify: document.getElementById("ssLinkSpotify").value.trim(),
        apple: document.getElementById("ssLinkApple").value.trim(),
        distrokid: document.getElementById("ssLinkDistrokid").value.trim()
      };
      localStorage.setItem("cdb_song_links_v1", JSON.stringify(all));
      const hf = document.getElementById("ssHyperfollowUsername")?.value.trim();
      if (hf) localStorage.setItem("cdb_hyperfollow_username_v1", hf);
    } catch (e) { /* тихо — само удобство, не пречи на основния pipeline */ }
  },

  // Опитва да намери РЕАЛНИ Spotify + Apple Music линкове за песента (търсене
  // по заглавие+артист). DistroKid НЯМА публичен search endpoint (не е
  // магазин/каталог с публични track страници) — остава ръчно поле.
  async findLinks() {
    const song = document.getElementById("ssSongName").value.trim();
    const artist = document.getElementById("ssArtistName").value.trim();
    const statusEl = document.getElementById("ssLinksStatus");
    if (!song) { toast("Първо въведи име на песента"); return; }
    if (statusEl) statusEl.textContent = "⏳ Търся...";
    let foundAny = false;
    let pageLinks = null;

    // Приоритет 1: ако песента я има в импортираната DistroKid библиотека,
    // директно ЧЕТЕМ реалната ѝ HyperFollow страница — тя вече съдържа
    // истинските Spotify/Apple/Deezer/iHeart/... линкове, вградени от самия
    // DistroKid (за Facebook/Instagram preview). Това е ТОЧНО тази песен,
    // без риск да хванем грешен артист със същото заглавие (какъвто риск
    // има при търсене по име в Spotify/iTunes API).
    const libMatch = this._findDistrokidLink(song);
    if (libMatch) {
      document.getElementById("ssLinkDistrokid").value = libMatch.url;
      foundAny = true;
      this.log(`✅ Намерена песента в библиотеката: "${libMatch.song}" → чета HyperFollow страницата ѝ...`);
      pageLinks = await this._fetchPlatformLinksFromPage(libMatch.url);
      if (pageLinks && pageLinks.spotify) { document.getElementById("ssLinkSpotify").value = pageLinks.spotify; foundAny = true; }
      if (pageLinks && pageLinks.apple) { document.getElementById("ssLinkApple").value = pageLinks.apple; foundAny = true; }
      if (pageLinks && Object.keys(pageLinks).length) {
        this.log(`✅ От HyperFollow страницата: ${Object.keys(pageLinks).map(k => this._platformLabel(k)).join(", ")}.`);
      } else {
        this.log("⚪ HyperFollow страницата не съдържа платформени линкове (може още да не е пуснала песента).");
      }
    }

    // Fallback (само ако песента НЕ е в библиотеката) — търсене по име през
    // Spotify Web API / iTunes Search API, с известен риск от грешно
    // съвпадение при често срещани заглавия.
    if (!pageLinks || !pageLinks.spotify) {
      try {
        const token = await NicheToolkit._getSpotifyToken();
        const q = artist ? `track:${song} artist:${artist}` : song;
        const res = await this._fetchViaProxies(`https://api.spotify.com/v1/search?q=${encodeURIComponent(q)}&type=track&limit=1`, {
          headers: { "Authorization": `Bearer ${token}` }
        }, 9000);
        if (res.ok) {
          const data = await res.json();
          const track = data.tracks?.items?.[0];
          const url = track?.external_urls?.spotify;
          if (url) {
            document.getElementById("ssLinkSpotify").value = url;
            foundAny = true;
            this.log(`✅ Намерен Spotify линк (търсене по име): ${track.name} — ${track.artists?.[0]?.name || "?"}`);
          } else {
            this.log("⚪ Spotify: няма намерена песен с това заглавие (може още да не е качена).");
          }
        } else {
          this.log(`⚠️ Spotify търсене неуспешно (${res.status}).`);
        }
      } catch (e) {
        this.log("⚠️ Spotify: " + e.message);
      }
    }

    if (!pageLinks || !pageLinks.apple) {
      try {
        const term = artist ? `${artist} ${song}` : song;
        const res = await this._fetchViaProxies(`https://itunes.apple.com/search?term=${encodeURIComponent(term)}&entity=song&limit=1`, {}, 9000);
        if (res.ok) {
          const data = await res.json();
          const track = data.results?.[0];
          const url = track?.trackViewUrl;
          if (url) {
            document.getElementById("ssLinkApple").value = url;
            foundAny = true;
            this.log(`✅ Намерен Apple Music линк (търсене по име): ${track.trackName} — ${track.artistName || "?"}`);
          } else {
            this.log("⚪ Apple Music: няма намерена песен с това заглавие.");
          }
        } else {
          this.log(`⚠️ Apple Music търсене неуспешно (${res.status}).`);
        }
      } catch (e) {
        this.log("⚠️ Apple Music: " + e.message);
      }
    }

    if (!libMatch) {
      const hfUsername = document.getElementById("ssHyperfollowUsername")?.value.trim().replace(/^@/, "");
      if (hfUsername) {
        try {
          const hfUrl = `https://hyperfollow.com/${encodeURIComponent(hfUsername)}`;
          const res = await this._fetchViaProxies(hfUrl, {}, 9000);
          if (res.ok) {
            document.getElementById("ssLinkDistrokid").value = hfUrl;
            foundAny = true;
            this.log(`✅ Намерена обща HyperFollow страница (не по конкретна песен): ${hfUrl}`);
          } else {
            this.log(`⚪ HyperFollow: страница "${hfUsername}" не е намерена (${res.status}) — провери юзърнейма или го попълни ръчно.`);
          }
        } catch (e) {
          this.log("⚠️ HyperFollow проверка: " + e.message);
        }
      } else {
        this.log("⚪ DistroKid: няма съвпадение в библиотеката и няма зададен юзърнейм — попълни ръчно или импортирай списъка.");
      }
    }

    this._saveLinks();
    if (statusEl) statusEl.textContent = foundAny
      ? "✅ Намерени линкове са попълнени по-горе — провери ги преди да продължиш."
      : "⚪ Нищо не се намери автоматично (нормално, ако песента още не е пусната) — можеш да въведеш ръчно.";
  },

  // Всички платформи, които DistroKid може да вгради в HyperFollow страница
  // (не само Spotify/Apple) — по домейн, за общо извличане с regex.
  // ЗАБЕЛЕЖКА: apple покрива И двата домейна, които DistroKid реално ползва —
  // music.apple.com (по-новите страници) И itunes.apple.com (все още срещан
  // формат, вкл. отделния "iTunes" бутон до "Apple Music") — преди се
  // хващаше само music.apple.com и itunes.apple.com линкове се губеха.
  _PLATFORM_PATTERNS: {
    spotify: /href="(https:\/\/open\.spotify\.com\/[^"]+)"/i,
    apple: /href="(https:\/\/(?:music|itunes)\.apple\.com\/[^"]+)"/i,
    youtube: /href="(https:\/\/(?:www\.)?youtube\.com\/[^"]+|https:\/\/youtu\.be\/[^"]+)"/i,
    youtubeMusic: /href="(https:\/\/music\.youtube\.com\/[^"]+)"/i,
    deezer: /href="(https:\/\/www\.deezer\.com\/[^"]+)"/i,
    tidal: /href="(https:\/\/(?:listen\.)?tidal\.com\/[^"]+)"/i,
    amazonMusic: /href="(https:\/\/(?:music|www)\.amazon\.[a-z.]+\/[^"]*(?:albums|dp)[^"]*)"/i,
    iheartradio: /href="(https:\/\/(?:www\.)?iheart\.com\/[^"]+)"/i,
    pandora: /href="(https:\/\/(?:www\.)?pandora\.com\/[^"]+)"/i,
    napster: /href="(https:\/\/(?:app|www)\.napster\.com\/[^"]+)"/i,
    soundcloud: /href="(https:\/\/(?:www\.)?soundcloud\.com\/[^"]+)"/i
  },
  _PLATFORM_LABELS: {
    spotify: "Spotify", apple: "Apple Music", youtube: "YouTube", youtubeMusic: "YouTube Music",
    deezer: "Deezer", tidal: "Tidal", amazonMusic: "Amazon Music", iheartradio: "iHeartRadio",
    pandora: "Pandora", napster: "Napster", soundcloud: "SoundCloud"
  },
  _platformLabel(key) { return this._PLATFORM_LABELS[key] || key; },

  // Декодира HTML entities (&#47; &#61; &#58; и т.н.) в нормален текст.
  // Някои HyperFollow страници сервират href стойностите entity-encoded
  // (напр. https:&#47;&#47;open.spotify.com&#47;...), които regex-ите по-долу
  // няма да хванат, ако не се декодират първо.
  _decodeHtml(str) {
    const el = document.createElement("textarea");
    el.innerHTML = str;
    return el.value;
  },

  // Чете реалната HyperFollow страница на песента и извлича ВСИЧКИ
  // платформени линкове, вградени в HTML-я ѝ (DistroKid ги слага директно
  // в страницата, за да работят Facebook/Instagram/Twitter preview-ите —
  // затова ги има без нужда от JS рендиране). Връща {spotify: "...", ...}
  // само с намерените платформи (празен обект, ако страницата не се зареди).
  // Първо декодира HTML entities (виж _decodeHtml), после пробва найдо-
  // надеждния източник (data-hyperfollow-store атрибута на всеки бутон —
  // разграничава apple/itunes изрично), и накрая — само за платформи, все
  // още ненамерени — общите regex-и по домейн като резерва.
  async _fetchPlatformLinksFromPage(url) {
    const found = {};
    try {
      // Пробва всички прокси кандидати поредно (виж _proxyCandidates) —
      // при провал/timeout на един минава директно на следващия, вместо да
      // спре цялото обогатяване на тази песен само защото първото прокси
      // виси/е претоварено (виж fix коментара при _getProxied по-горе).
      const res = await this._fetchViaProxies(url, {}, 9000);
      const html = this._decodeHtml(await res.text());

      // Първичен източник: data-hyperfollow-store атрибут (най-надежден,
      // разграничава Apple Music от iTunes изрично).
      const storeRe = /data-testid="hyperfollow-store-link"[^>]*data-hyperfollow-store="([^"]+)"[^>]*href="([^"]+)"/g;
      let m;
      while ((m = storeRe.exec(html)) !== null) {
        const key = m[1] === "applemusic" ? "apple" : m[1];
        found[key] = m[2];
      }

      // Резервен източник: regex по домейн — само за платформи, които
      // горният атрибут не покри (по-стари страници без този атрибут).
      for (const [key, re] of Object.entries(this._PLATFORM_PATTERNS)) {
        if (found[key]) continue;
        const mm = html.match(re);
        if (mm) found[key] = mm[1];
      }

      // Диагностика: ако страницата се прочете успешно, но НИЩО не се
      // намери (нито по атрибут, нито по regex) — почти сигурно DistroKid
      // е сменил HTML структурата си, или проксито връща error/placeholder
      // страница вместо реалния HyperFollow HTML. Логваме дължина + откъс,
      // за да е ясно кое от двете е.
      if (!Object.keys(found).length) {
        this.log(`⚪ HyperFollow страницата се прочете (${html.length} символа), но не намерих нито един линк в нея — откъс: "${html.replace(/\s+/g, " ").slice(0, 160)}..."`);
      }
    } catch (e) { this.log(`⚠️ Четене на HyperFollow страницата (${url}) — и трите прокси опита отказаха: ${e.message}`); }
    return found;
  },

  log(msg) {
    const el = document.getElementById("ssLog");
    if (!el) return;
    const time = new Date().toLocaleTimeString("bg-BG");
    el.innerHTML += `<div>[${time}] ${msg}</div>`;
    el.scrollTop = el.scrollHeight;
  },

  _setRunning(v) {
    const btn = document.getElementById("ssStartBtn");
    if (btn) btn.disabled = v;
    const spinner = document.getElementById("ssRunning");
    if (spinner) spinner.style.display = v ? "block" : "none";
  },

  _pastedLyrics() {
    const el = document.getElementById("ssLyricsPaste");
    return el ? el.value.trim() : "";
  },

  _getCount() {
    const el = document.getElementById("ssCount");
    return el ? parseInt(el.value, 10) || 3 : 3;
  },

  // Чете продължителността на аудиото в браузъра (нужна на AI-я, за да не
  // предлага timestamp-и извън реалната дължина на песента).
  _getAudioDuration(file) {
    return new Promise((resolve, reject) => {
      const el = new Audio();
      el.preload = "metadata";
      el.onloadedmetadata = () => { const d = el.duration; URL.revokeObjectURL(el.src); resolve(d); };
      el.onerror = () => reject(new Error("Не успях да прочета продължителността на аудиото."));
      el.src = URL.createObjectURL(file);
    });
  },

  _fmtTime(t) {
    if (!isFinite(t) || t < 0) t = 0;
    const m = Math.floor(t / 60), s = Math.floor(t % 60);
    return m + ":" + String(s).padStart(2, "0");
  },

  // Тример за overlay текста ("кукичката") върху видеото — виж бележката
  // при мястото на извикване (analyzeAndSelect по-долу) за пълния контекст
  // защо точно 40 символа и защо word-boundary, не твърд символен срез.
  _trimHookText(text, maxLen = 40) {
    const trimmed = (text || "").toString().trim();
    if (trimmed.length <= maxLen) return trimmed;
    let cut = trimmed.slice(0, maxLen);
    const lastSpace = cut.lastIndexOf(" ");
    if (lastSpace > maxLen * 0.5) cut = cut.slice(0, lastSpace);
    return cut.replace(/[,\s]+$/, "").trim();
  },

  // =========================================================
  // 🎬 AI SHORTS PRO — сървърен pipeline (js/shorts-pro-render.js +
  // .github/workflows/render-pro-short.yml), замества горния client-side
  // flow (runFull/_analyzeAndPickMoments/_renderAllClips по-долу, вече не
  // се викат от никой бутон — виж коментара при <iframe id=
  // "shortsVisualizerFrame"> в index.html). Разлики от стария flow:
  //   - Gemini/Whisper/FFmpeg анализът+рендерът текат СЪРВЪРНО (по-бързо,
  //     не блокира/грее браузъра, работи и от телефон)
  //   - вградени субтитри (Whisper) — старият flow нямаше
  //   - ЕДИН Short на клик (сървърният скрипт избира 1 "най-силен" момент,
  //     без опция да поиска "различен от предишния" — виж discussion-а,
  //     затова махнахме "Колко Shorts да направи?" избора от UI)
  //   - качва се АВТОМАТИЧНО в YouTube накрая (ако си вписан горе), вместо
  //     да чака преглед/редакция на всеки клип поотделно
  // =========================================================

  // --- Временен публичен URL за upload-нат файл — Contents API (api.github.com) ---
  // ЗАЩО НЕ Releases API: uploads.github.com (upload_url на Releases) НЕ
  // поддържа CORS — само api.github.com го поддържа официално (виж GitHub
  // Docs "CORS and JSONP"). Браузърен fetch() към uploads.github.com гърми
  // с генеричен мрежов "Failed to fetch" (без ясна CORS грешка в конзолата
  // дори). Затова тук ползваме СЪЩИЯ Contents API механизъм като
  // saveLibraryToGitHub() по-горе — вече доказано работещ.
  // Лимити (виж GitHub Docs "Create or update file contents"): до 100MB на
  // файл официално, но на практика някои получават 422 "too large to be
  // processed" някъде между ~25-50MB — за нормален .mp3 (няколко MB) е ОК.
  // base64 добавя ~33% overhead към payload-а.
  async _ghPutTempFile(k, path, file) {
    const branch = k.ghBranch || "main";
    const content = await fileToBase64(file);
    const res = await fetchTimeout(
      `https://api.github.com/repos/${k.ghOwner}/${k.ghRepo}/contents/${path}`,
      {
        method: "PUT",
        headers: { Authorization: `Bearer ${k.ghToken}`, Accept: "application/vnd.github+json", "Content-Type": "application/json" },
        body: JSON.stringify({ message: `🎬 AI Shorts Pro: временен файл ${path}`, content, branch }),
      },
      5 * 60 * 1000
    );
    if (!res.ok) throw new Error(`GitHub ${res.status}: ${(await res.text()).slice(0, 300)}`);
    const json = await res.json();
    return {
      // raw.githubusercontent.com е публичен CDN без auth — точно каквото
      // трябва на GitHub Actions runner-а (requests.get, не браузър —
      // CORS изобщо не важи там). Малък риск: CDN кеш може да закъснее
      // няколко секунди след push — dispatch()-ът по-долу тръгва веднага
      // след upload-а, но самият workflow run отнема секунди преди да
      // стигне до download стъпката, така че на практика не сме забелязвали проблем.
      url: `https://raw.githubusercontent.com/${k.ghOwner}/${k.ghRepo}/${branch}/${path}`,
      sha: json.content?.sha,
    };
  },

  // Best-effort чистене след завършен job — да не се трупат осиротели
  // файлове в git история-та. Провалът тук НЕ трябва да развали резултата
  // за потребителя (видеото вече е готово) — затова само console.warn.
  async _ghDeleteTempFile(k, path, sha) {
    if (!sha) return;
    try {
      await fetchTimeout(
        `https://api.github.com/repos/${k.ghOwner}/${k.ghRepo}/contents/${path}`,
        {
          method: "DELETE",
          headers: { Authorization: `Bearer ${k.ghToken}`, Accept: "application/vnd.github+json", "Content-Type": "application/json" },
          body: JSON.stringify({ message: `🎬 AI Shorts Pro: чистене на ${path}`, sha, branch: k.ghBranch || "main" }),
        },
        20000
      );
    } catch (e) { console.warn("Чистене на временен файл се провали (не е фатално):", path, e); }
  },

  // --- Relay път (до 2GB) — виж scripts/shorts-relay-server/README.md ---
  // Активен само ако потребителят е конфигурирал Keys.load().shortsRelayUrl
  // (Настройки → API Ключове → "🎬 Shorts Relay"). Създава ОБИЧАЙНА GitHub
  // Release (api.github.com — CORS работи директно, нищо специално не е
  // нужно тук), после ЗАСЕБНО качва всеки asset през relay-я (защото самото
  // качване е това, което гърми CORS — не създаването на release-а).
  async _ghCreateShortsJobRelease(k, tagName) {
    const res = await fetchTimeout(
      `https://api.github.com/repos/${k.ghOwner}/${k.ghRepo}/releases`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${k.ghToken}`, Accept: "application/vnd.github+json", "Content-Type": "application/json" },
        body: JSON.stringify({
          tag_name: tagName,
          target_commitish: k.ghBranch || "main",
          name: `🎬 AI Shorts Pro job ${tagName}`,
          body: "Автоматично създаден за временен публичен URL на аудио/обложка (upload през relay сървър — виж scripts/shorts-relay-server/). Трие се автоматично след завършен job, или до 24ч резервно от scripts/cleanup_mastering_jobs.py.",
          draft: false,
          prerelease: true,
        }),
      },
      20000
    );
    if (!res.ok) throw new Error(`GitHub ${res.status}: ${(await res.text()).slice(0, 300)}`);
    return res.json();
  },

  async _relayUploadReleaseAsset(k, release, filename, file) {
    const base = release.upload_url.replace(/\{.*\}$/, "");
    const targetUrl = `${base}?name=${encodeURIComponent(filename)}`;
    const res = await fetchTimeout(
      `${k.shortsRelayUrl}/upload`,
      {
        method: "POST",
        headers: {
          "X-Proxy-Secret": k.shortsRelaySecret,
          "X-Target-Url": targetUrl,
          Authorization: `Bearer ${k.ghToken}`,
          "Content-Type": file.type || "application/octet-stream",
        },
        body: file,
      },
      20 * 60 * 1000 // до 20 мин — голям файл + евентуален Render cold start
    );
    if (!res.ok) throw new Error(`Relay upload ${res.status}: ${(await res.text()).slice(0, 300)}`);
    const asset = await res.json();
    return { url: asset.browser_download_url };
  },

  // Изтрива release + git таг — best-effort, НЕ блокира резултата.
  async _ghDeleteRelease(k, releaseId, tagName) {
    try {
      await fetchTimeout(
        `https://api.github.com/repos/${k.ghOwner}/${k.ghRepo}/releases/${releaseId}`,
        { method: "DELETE", headers: { Authorization: `Bearer ${k.ghToken}`, Accept: "application/vnd.github+json" } },
        20000
      );
    } catch (e) { console.warn("Изтриване на temp release се провали (не е фатално):", e); }
    try {
      await fetchTimeout(
        `https://api.github.com/repos/${k.ghOwner}/${k.ghRepo}/git/refs/tags/${encodeURIComponent(tagName)}`,
        { method: "DELETE", headers: { Authorization: `Bearer ${k.ghToken}`, Accept: "application/vnd.github+json" } },
        20000
      );
    } catch (e) { console.warn("Изтриване на temp git таг се провали (не е фатално):", e); }
  },

  // Единна входна точка за upload на 1 файл — сама решава кой път да ползва
  // (relay+Releases до 2GB, или Contents API до ~100MB) според настройките.
  // `release` се подава само в relay режим (създава се ВЕДНЪЖ на job,
  // споделя се между audio+cover — виж повикването в runProRender()).
  async _uploadShortsFile(k, useRelay, release, jobDir, filename, file) {
    if (useRelay) {
      const asset = await this._relayUploadReleaseAsset(k, release, filename, file);
      return { url: asset.url, cleanup: null }; // release-ът се трие целия наведнъж по-долу
    }
    const path = `${jobDir}/${filename}`;
    const asset = await this._ghPutTempFile(k, path, file);
    return { url: asset.url, cleanup: { path, sha: asset.sha } };
  },

  // Fallback обложка, ако потребителят не е качил своя: същото iTunes
  // Search, което вече ползва enrichLibrary() за библиотечните песни, само
  // че тук резултатът НЕ се пази в библиотеката (произволен upload, не е
  // задължително част от нея).
  async _findCoverViaItunes(artist, song) {
    try {
      const term = `${artist} ${song}`;
      const res = await this._fetchViaProxies(`https://itunes.apple.com/search?term=${encodeURIComponent(term)}&entity=song&limit=1`, {}, 9000);
      if (!res.ok) return "";
      const d = await res.json();
      const art = d.results?.[0]?.artworkUrl100;
      return art ? art.replace("100x100bb", "1200x1200bb") : "";
    } catch (e) { return ""; }
  },

  // Главен вход на новия pipeline — извиква се от 🚀 бутона в index.html.
  async runProRender() {
    if (!this.audioFile) return toast("Първо избери аудио файл");
    const k = Keys.load();
    if (!k.ghToken || !k.ghOwner || !k.ghRepo) {
      return toast("❌ Липсва GitHub Token/owner/repo — виж Настройки → API Ключове (нужни права: repo contents + Actions за този токен)");
    }
    const useRelay = !!(k.shortsRelayUrl && k.shortsRelaySecret);
    const songNameEl = document.getElementById("ssSongName");
    const artistEl = document.getElementById("ssArtistName");
    const song = (songNameEl && songNameEl.value.trim()) || this.audioFile.name.replace(/\.[^/.]+$/, "");
    const artist = (artistEl && artistEl.value.trim()) || "";
    if (!artist) return toast("❌ Въведи \"Артист/канал\" — нужно е за обложката и метаданните.");
    const overlayTextEl = document.getElementById("ssOverlayText");
    const overlayText = (overlayTextEl && overlayTextEl.value.trim()) || "";
    if (!overlayText) return toast("❌ Напиши текста, който да излезе върху обложката (полето \"✍️ Текст върху обложката\").");
    const fontChoice = document.getElementById("ssFontChoice")?.value || "russoone";
    const textEffect = document.getElementById("ssTextEffect")?.value || "glow_pulse";
    const videoStyle = document.getElementById("ssVideoStyle")?.value || "auto";
    if (!useRelay && this.audioFile.size > 90 * 1024 * 1024) {
      return toast("❌ Файлът е над ~90MB, а Relay не е конфигуриран (Настройки → API Ключове → \"🎬 Shorts Relay\") — Contents API пътят не е сигурен над този размер. Виж scripts/shorts-relay-server/README.md.", 8000);
    }

    document.getElementById("ssLog").innerHTML = "";
    document.getElementById("ssProResultWrap").style.display = "none";
    this._setRunning(true);
    this.log(`🚀 Стартирам AI Shorts Pro за "${song}" (${artist})... [${useRelay ? "Relay път, до 2GB" : "Contents API път, до ~100MB"}]`);

    try {
      const jobId = (window.crypto && window.crypto.randomUUID) ? window.crypto.randomUUID() : "job-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10);
      const jobDir = `shorts-tmp/${jobId}`;
      const tagName = `shorts-job-${jobId}`;

      let release = null;
      if (useRelay) {
        this.log("⏳ Създавам временен GitHub Release (2GB upload път)...");
        release = await this._ghCreateShortsJobRelease(k, tagName);
      }

      this.log(`⏳ Качвам аудиото (${this.audioFile.name}, ${(this.audioFile.size / 1024 / 1024).toFixed(1)}MB)${useRelay ? " през relay-я..." : "..."}`);
      const audioFilename = "audio" + (this.audioFile.name.match(/\.[^/.]+$/)?.[0] || ".mp3");
      const audioAsset = await this._uploadShortsFile(k, useRelay, release, jobDir, audioFilename, this.audioFile);

      let coverCleanup = null;
      let coverUrl = "";
      const coverInput = document.getElementById("ssCoverFile");
      const coverFile = coverInput && coverInput.files[0];
      if (coverFile) {
        this.log(`⏳ Качвам обложката (${coverFile.name})...`);
        const coverFilename = "cover" + (coverFile.name.match(/\.[^/.]+$/)?.[0] || ".jpg");
        const coverAsset = await this._uploadShortsFile(k, useRelay, release, jobDir, coverFilename, coverFile);
        coverUrl = coverAsset.url;
        coverCleanup = coverAsset.cleanup;
      } else {
        this.log("🔍 Няма качена обложка — търся автоматично през Apple Music (iTunes Search)...");
        coverUrl = await this._findCoverViaItunes(artist, song);
        if (!coverUrl) {
          this.log("❌ Не намерих обложка автоматично.");
          toast("❌ Не намерих обложка автоматично — качи обложка ръчно (полето по-горе) и опитай пак.", 6000);
          return;
        }
        this.log("✅ Намерих обложка през Apple Music.");
      }

      if (typeof ShortsProRender === "undefined") {
        this.log("❌ js/shorts-pro-render.js не е зареден — провери index.html.");
        return;
      }
      this.log("🎬 Тригвам сървърния рендер (GitHub Actions)...");
      const result = await ShortsProRender.dispatch({
        song, artist, audio_url: audioAsset.url, cover_url: coverUrl,
        overlay_text: overlayText, font_choice: fontChoice, text_effect: textEffect, video_style: videoStyle,
      });

      // Чистене на временните файлове/release-а — best-effort, НЕ блокира
      // резултата за потребителя. Правим го СЛЕД dispatch()-а завършва (не
      // по-рано!) — runner-ът трябва вече да е свалил файловете дотук.
      if (useRelay) {
        this._ghDeleteRelease(k, release.id, tagName);
      } else {
        if (audioAsset.cleanup) this._ghDeleteTempFile(k, audioAsset.cleanup.path, audioAsset.cleanup.sha);
        if (coverCleanup) this._ghDeleteTempFile(k, coverCleanup.path, coverCleanup.sha);
      }

      if (!result || !result.ok) {
        this.log("❌ Рендерът не завърши успешно (виж toast-а по-горе за подробности).");
        return;
      }
      if (!result.videoBlob) {
        this.log("⚠️ Видеото е готово, но не успях да го разархивирам автоматично тук — виж бутона за ръчно сваляне (toast-а по-горе) и качи ръчно в YouTube.");
        return;
      }
      this.log(`✅ Видеото е готово (${result.videoFilename}).`);
      await this._autoUploadProResult(result, song, artist);
    } catch (e) {
      this.log("❌ Грешка: " + e.message);
      toast("❌ " + e.message, 6000);
    } finally {
      this._setRunning(false);
    }
  },

  // Взима title/description/hashtags от report.json (ако го има — виж
  // downloadResultZip() в js/shorts-pro-render.js), качва videoBlob-а
  // директно в YouTube през Step4.uploadVideo() (fileOverride/metaOverride,
  // същия механизъм като QuickUpload — виж header коментара на файла).
  // Ако потребителят не е вписан в Google — не гърми, а показва бутон за
  // РЪЧНО сваляне на .mp4-то (videoBlob вече е в паметта, не се губи).
  async _autoUploadProResult(result, song, artist) {
    const report = result.report || {};
    const title = report.title || `${song} — ${artist} | Short`;
    const description = report.description || "";
    const tags = Array.isArray(report.hashtags) ? report.hashtags.map(h => h.replace(/^#/, "")).filter(Boolean) : [];
    const videoFile = new File([result.videoBlob], result.videoFilename || `${song}.mp4`, { type: "video/mp4" });

    const wrap = document.getElementById("ssProResultWrap");
    const body = document.getElementById("ssProResultBody");
    wrap.style.display = "block";

    if (!Step4.accessToken) {
      this.log("⚠️ Не си вписан в YouTube (Стъпка 2 по-горе) — качвам ръчно сваляне на .mp4-то вместо автоматично качване.");
      const url = URL.createObjectURL(result.videoBlob);
      body.innerHTML = `<p class="muted">Не беше активен YouTube вход по време на рендера — ето .mp4-то за ръчно сваляне/качване:</p>
        <a class="btn ghost" href="${this._escAttr(url)}" download="${this._escAttr(videoFile.name)}">⬇️ Свали ${this._esc(videoFile.name)}</a>
        <p class="muted" style="margin-top:8px;"><strong>Заглавие:</strong> ${this._esc(title)}</p>`;
      return;
    }

    this.log("⬆️ Качвам автоматично в YouTube (unlisted)...");
    body.innerHTML = `<div id="ssProUploadProgress" class="muted">⏳ Качвам...</div>`;
    try {
      const ytResult = await Step4.uploadVideo(videoFile, { title, description, tags, madeForKids: false }, "ssProUploadProgress");
      this.log(`✅ Качено в YouTube! Video ID: ${ytResult.id} (unlisted)`);
      body.innerHTML = `<p>✅ Качено в YouTube (unlisted) — <a href="https://www.youtube.com/watch?v=${this._escAttr(ytResult.id)}" target="_blank" rel="noopener">отвори видеото</a></p>
        <p class="muted" style="margin-top:6px;"><strong>Заглавие:</strong> ${this._esc(title)}</p>`;
    } catch (e) {
      this.log("❌ Качването в YouTube се провали: " + e.message + " — ето .mp4-то за ръчно качване.");
      const url = URL.createObjectURL(result.videoBlob);
      body.innerHTML = `<p class="muted">❌ Автоматичното качване се провали (${this._esc(e.message)}). Ръчно сваляне:</p>
        <a class="btn ghost" href="${this._escAttr(url)}" download="${this._escAttr(videoFile.name)}">⬇️ Свали ${this._esc(videoFile.name)}</a>`;
    }
  },

  // Основен вход — целият pipeline: анализ+избор на моменти → метаданни → видео за всеки → преглед.
  async runFull() {
    if (!this.audioFile) return toast("Първо избери аудио файл");
    const songNameEl = document.getElementById("ssSongName");
    const songName = (songNameEl && songNameEl.value.trim()) || this.audioFile.name.replace(/\.[^/.]+$/, "");
    const count = this._getCount();

    this.items = [];
    this.analysis = null;
    document.getElementById("ssLog").innerHTML = "";
    document.getElementById("ssResultsWrap").style.display = "none";
    document.getElementById("ssItemsWrap").innerHTML = "";
    const progWrap = document.getElementById("ssVideoProgressWrap");
    if (progWrap) progWrap.style.display = "none";
    this._setRunning(true);
    this.log(`🚀 Стартирам — искам ${count} различен Short${count > 1 ? "а" : ""} от "${songName}".`);

    try {
      await this._analyzeAndPickMoments(songName, count);
      await this._generateMetaForAll(songName, count);
      await this._renderAllClips(songName);
      this._renderResults();
      document.getElementById("ssResultsWrap").style.display = "block";
      this.log("🎉 Всички Shorts са готови — прегледай/поправи по-долу и качи с бутона.");
    } catch (e) {
      this.log("❌ Грешка: " + e.message);
    } finally {
      this._setRunning(false);
    }
  },

  async _analyzeAndPickMoments(songName, count) {
    this.log("🎧 Gemini слуша песента и избира " + count + " различни \"hook\" момента (за максимален watch time)...");
    const totalDur = await this._getAudioDuration(this.audioFile);
    const base64 = await fileToBase64(this.audioFile);
    const mimeType = this.audioFile.type || "audio/mpeg";
    const pasted = this._pastedLyrics();

    const prompt = `Ти си музикален анализатор и YouTube Shorts стратег. Слушай приложения аудио файл (песен "${songName}", обща продължителност ${Math.round(totalDur)} секунди / ${this._fmtTime(totalDur)}) и направи следното:

1. Анализирай звука: genre (жанр/поджанр, 2-4 думи), mood (настроение, 2-4 думи), energy ("ниско"/"средно"/"високо"), language (ЕЗИКЪТ, на който се пее — определи го САМО от това, което чуваш), language_code (ISO 639-1, напр. "bg"/"en").
2. lyrics — текстът на песента, на РЕАЛНИЯ й език (НЕ превеждай)${pasted ? " — по-долу е дадена ГОТОВА версия от потребителя, ползвай я КАКТО Е" : " — РАЗПОЗНАЙ го от аудиото, доколкото е разбираемо"}.
${pasted ? `Текст, пейстнат от потребителя:\n---\n${pasted}\n---\n` : ""}
3. Избери ТОЧНО ${count} различни, силно "залепващи" момента от песента, всеки — кандидат за отделен YouTube Short:
   - "start"/"end" в секунди, цели числа, 0 <= start < end <= ${Math.floor(totalDur)}
   - продължителност на всеки момент между 18 и 58 секунди
   - предпочитай момент, който звучи завършено сам по себе си (хук/припев/drop/емоционален връх/изненадващ ред), не по средата на дума
   - ${count > 1 ? `ЗАДЪЛЖИТЕЛНО ${count}-те момента трябва да са от РАЗЛИЧНИ части на песента (не се припокриват, различно усещане всеки — напр. интро-кука, припев, бридж/drop, финален момент и т.н.)` : "избери НАЙ-силния 1 момент от цялата песен"}
   - "hook_reason": 1 изречение защо точно този момент е избран (вътрешна бележка, не се показва публично)
   - "hook_text": кратък текст за overlay върху видеото (до 40 символа), на езика на песента, който възбужда любопитство/емоция (не просто заглавието на песента)

Върни ЧИСТ JSON, без нищо друго:
{"genre":"...", "mood":"...", "energy":"...", "language":"...", "language_code":"...", "lyrics":"...", "segments":[{"start":0,"end":30,"hook_reason":"...","hook_text":"..."}]}`;

    const raw = await callGeminiMultimodal(prompt, base64, mimeType);
    const parsed = extractJson(raw);
    this.analysis = {
      genre: parsed.genre, mood: parsed.mood, energy: parsed.energy,
      language: parsed.language, language_code: parsed.language_code, lyrics: parsed.lyrics
    };
    let segments = Array.isArray(parsed.segments) ? parsed.segments : [];

    // Гаранция на кода (не само на промпта): изрязваме/поправяме диапазони извън
    // реалната продължителност на файла и подсигуряваме точен брой елементи,
    // за да не се счупи рендерирането по-долу дори ако AI-я върне грешен формат.
    // hook_text: промптът по-горе иска "до 40 символа", НО кодът досега режеше
    // на 60 — несъответствие, което позволяваше по-дълъг текст да мине. Важно е
    // точно тук, защото visualizer.html рисува hook_text като overlay в canvas
    // с АВТОМАТИЧНО смаляващ се шрифт (виж drawTitle() в visualizer.html), но
    // с долен праг на размера (H*0.02) — прекалено дълъг текст просто ПРЕЛИВА
    // извън зоната вместо да продължи да се смалява. _trimHookText() е твърдата
    // гаранция, аналогична на formatSunoStyleTags() (js/song-lab.js) — никога
    // не разцепва дума по средата.
    segments = segments
      .map(s => ({
        start: Math.max(0, Math.floor(Number(s.start) || 0)),
        end: Math.min(Math.floor(totalDur), Math.ceil(Number(s.end) || 0)),
        hook_reason: s.hook_reason || "",
        hook_text: this._trimHookText(s.hook_text || songName)
      }))
      .filter(s => s.end - s.start >= 10)
      .slice(0, count);

    if (!segments.length) {
      // Резервен вариант, ако AI-ят не върне валидни диапазони — равномерно
      // разпределени 30-сек. откъса по цялата песен, за да не спре целият pipeline.
      const clipLen = Math.min(30, Math.max(15, Math.floor(totalDur / (count + 1))));
      for (let i = 0; i < count; i++) {
        const start = Math.floor((totalDur / (count + 1)) * (i + 1) - clipLen / 2);
        segments.push({ start: Math.max(0, start), end: Math.min(Math.floor(totalDur), Math.max(0, start) + clipLen), hook_reason: "резервен избор", hook_text: songName });
      }
      this.log("⚠️ AI-ят не върна валидни моменти — ползвам резервно равномерно разпределение.");
    }
    while (segments.length < count) segments.push(segments[segments.length - 1]);

    this.items = segments.map((s, i) => ({
      index: i, start: s.start, end: s.end, hookReason: s.hook_reason, hookText: s.hook_text,
      title: "", description: "", tags: [], videoBlob: null, fileName: "", status: "pending"
    }));
    this.log(`✅ Избрани моменти: ` + this.items.map(it => `#${it.index + 1} [${this._fmtTime(it.start)}–${this._fmtTime(it.end)}]`).join(", "));
  },

  async _generateMetaForAll(songName, count) {
    this.log("✍️ Claude генерира заглавие/описание/хаштагове за всеки Short (всеки — различен ъгъл)...");
    const a = this.analysis || {};
    const segList = this.items.map(it =>
      `#${it.index + 1}: [${this._fmtTime(it.start)}–${this._fmtTime(it.end)}] причина: ${it.hookReason || "—"} · overlay текст: "${it.hookText}"`
    ).join("\n");

    const prompt = `За YouTube Shorts от песента "${songName}" (жанр: ${a.genre || "?"}, настроение: ${a.mood || "?"}, енергия: ${a.energy || "?"}, език: ${a.language || "?"} / ${a.language_code || "?"}).
Текст на песента (откъс, за контекст на темата — НЕ го копирай изцяло): ${(a.lyrics || "").slice(0, 600)}

По-долу е списък от ${count} различни момента от песента, всеки ще стане ОТДЕЛЕН YouTube Short:
${segList}

За ВСЕКИ от ${count}-те момента (в СЪЩИЯ ред по номер) генерирай метаданни, оптимизирани за максимален watch time и виралност:
- title: ЗАДЪЛЖИТЕЛНО започва или съдържа точното име на песента "${songName}", плюс кука/curiosity gap базирана на overlay текста и причината за момента; до 90 символа общо; на езика на песента (${a.language || "?"}); може 1 подходящ emoji
- description: на езика на песента — 2-3 изречения хук/контекст за конкретния момент (НЕ generic), после точно тези 3 реда (ТОЧНО както са, само добави текста на езика на песента, НЕ пипай токените в {{...}} и НЕ ги замествай с истински линкове — те се вкарват автоматично от кода):
🎧 ${a.language_code === "bg" ? "Слушай в Spotify" : "Listen on Spotify"}: {{SPOTIFY_LINK}}
🍏 ${a.language_code === "bg" ? "Слушай в Apple Music" : "Listen on Apple Music"}: {{APPLE_LINK}}
📀 ${a.language_code === "bg" ? "Още платформи" : "More platforms"}: {{DISTROKID_LINK}}
После блок от 15-20 релевантни хаштага с # (ЗАДЪЛЖИТЕЛНО включва #shorts и #short, плюс жанрови/тематични/общи viral хаштагове, разумна смесица от езика на песента и общоприети английски)
- tags: масив от 10-15 YouTube ключови тагове (кратки думи/фрази, БЕЗ #), предимно на езика на песента + 1-2 общоприети английски (жанр, "shorts" и т.н.)

ЗАДЪЛЖИТЕЛНО: ${count > 1 ? `всичките ${count} комплекта title/description ТРЯБВА да звучат забележимо различно едно от друго (различен ъгъл/кука за всеки момент) — НЕ преизползвай едни и същи фрази/структура.` : "направи го възможно най-примамливо за клик."}

Върни ЧИСТ JSON масив от точно ${count} обекта, по един на всеки момент, В СЪЩИЯ РЕД:
[{"title":"...", "description":"...", "tags":["...", "..."]}]`;

    const raw = await callAI(prompt, 1400);
    let metaList = extractJson(raw);
    if (!Array.isArray(metaList)) metaList = [metaList].filter(Boolean);

    this.items.forEach((it, i) => {
      const m = metaList[i] || {};
      let title = (m.title || `${songName} - Short ${i + 1}`).toString().trim();
      if (!title.toLowerCase().includes(songName.trim().toLowerCase())) title = `${songName} - ${title}`;
      it.title = title.slice(0, 100);
      it.description = (m.description || `${songName}\n\n#shorts #short`).toString();
      it.tags = Array.isArray(m.tags) ? m.tags.map(t => String(t).trim()).filter(Boolean) : [];
    });
    this._injectLinks();
    this.log("✅ Заглавия/описания/тагове готови за всичките " + count + ".");
  },

  // Детерминирано замества {{SPOTIFY_LINK}}/{{APPLE_LINK}}/{{DISTROKID_LINK}}
  // токените с реалните стойности от полетата (или трие целия ред, ако е
  // празно) — AI-ят никога не пипа/измисля реални URL-и, само оставя токена.
  _injectLinks() {
    const links = {
      SPOTIFY_LINK: document.getElementById("ssLinkSpotify")?.value.trim() || "",
      APPLE_LINK: document.getElementById("ssLinkApple")?.value.trim() || "",
      DISTROKID_LINK: document.getElementById("ssLinkDistrokid")?.value.trim() || ""
    };
    this.items.forEach(it => {
      it.description = it.description
        .split("\n")
        .map(line => {
          const tokenMatch = line.match(/\{\{(SPOTIFY_LINK|APPLE_LINK|DISTROKID_LINK)\}\}/);
          if (!tokenMatch) return line;
          const val = links[tokenMatch[1]];
          if (!val) return null; // празен линк → редът изчезва изцяло, не оставяме "{{...}}" в описанието
          return line.replace(/\{\{(SPOTIFY_LINK|APPLE_LINK|DISTROKID_LINK)\}\}/, val);
        })
        .filter(line => line !== null)
        .join("\n");
    });
  },

  // Рендерира клиповете ПОСЛЕДОВАТЕЛНО (един по един) — визуализаторът е canvas
  // recording, не може да пише две видеа паралелно в един и същ таб.
  async _renderAllClips(songName) {
    this._bindMessageListener();
    const total = this.items.length;
    for (let i = 0; i < total; i++) {
      const it = this.items[i];
      this.log(`🎬 Клип ${i + 1}/${total} [${this._fmtTime(it.start)}–${this._fmtTime(it.end)}] — рендирам вертикално видео...`);
      this._setClipProgress(i + 1, total, 0);
      await this._renderOneClip(it);
      this.log(`✅ Клип ${i + 1}/${total} готов (${Math.round(it.videoBlob.size / 1024 / 1024 * 10) / 10} MB).`);
    }
  },

  _setClipProgress(current, total, pct) {
    const wrap = document.getElementById("ssVideoProgressWrap");
    const bar = document.getElementById("ssVideoProgressBar");
    const label = document.getElementById("ssVideoProgressLabel");
    if (!bar) return;
    if (wrap) wrap.style.display = "block";
    bar.style.width = pct + "%";
    if (label) label.textContent = pct >= 100
      ? `Клип ${current}/${total}: готово ✅`
      : `Клип ${current}/${total}: записва се… ${pct}%`;
  },

  _bindMessageListener() {
    if (this._msgBound) return;
    this._msgBound = true;
    window.addEventListener("message", (ev) => {
      const frame = document.getElementById("shortsVisualizerFrame");
      if (!frame || ev.source !== frame.contentWindow || !ev.data) return;
      if (ev.data.type === "cdb-video-ready" && this._pendingResolve) {
        const resolve = this._pendingResolve;
        this._pendingResolve = null;
        resolve({ blob: ev.data.blob, fileName: ev.data.fileName || "short.webm" });
      }
      if (ev.data.type === "cdb-video-progress" && this._pendingIndex != null) {
        this._setClipProgress(this._pendingIndex + 1, this.items.length, ev.data.percent);
      }
      if (ev.data.type === "cdb-video-error" && this._pendingReject) {
        const reject = this._pendingReject;
        this._pendingReject = null;
        reject(new Error(ev.data.message || "Грешка от визуализатора"));
      }
    });
  },

  _renderOneClip(item) {
    return new Promise((resolve, reject) => {
      this._pendingIndex = item.index;
      this._pendingResolve = async ({ blob, fileName }) => {
        item.videoBlob = blob;
        item.fileName = fileName;
        item.status = "rendered";
        resolve();
      };
      this._pendingReject = (err) => { item.status = "error"; reject(err); };

      const frame = document.getElementById("shortsVisualizerFrame");
      const send = () => frame.contentWindow.postMessage({
        type: "cdb-quick-audio",
        file: this.audioFile,
        title: item.hookText,
        clipStart: item.start,
        clipEnd: item.end,
        aspect: "9:16"
      }, "*");
      // Презареждаме iframe-а за всеки клип — гарантира чисто, свежо състояние
      // на визуализатора (без остатъчни clip/aspect стойности от предния клип).
      frame.onload = send;
      frame.src = "visualizer.html";
    });
  },

  _renderResults() {
    const wrap = document.getElementById("ssItemsWrap");
    wrap.innerHTML = this.items.map(it => {
      const url = URL.createObjectURL(it.videoBlob);
      return `
      <div class="card" style="margin-top:12px;" id="ssItem${it.index}">
        <strong>Short ${it.index + 1} · ${this._fmtTime(it.start)}–${this._fmtTime(it.end)}</strong>
        <video src="${url}" controls playsinline style="max-width:220px;width:100%;border-radius:10px;margin-top:8px;display:block;background:#000;"></video>
        <label style="margin-top:10px;">Заглавие</label>
        <input type="text" id="ssTitle${it.index}" value="${this._escAttr(it.title)}">
        <label style="margin-top:8px;">Описание</label>
        <textarea id="ssDesc${it.index}" style="min-height:110px;">${this._esc(it.description)}</textarea>
        <label style="margin-top:8px;">Тагове (запетая разделени)</label>
        <input type="text" id="ssTags${it.index}" value="${this._escAttr(it.tags.join(", "))}">
        <div id="ssItemUploadStatus${it.index}" class="muted" style="margin-top:8px;"></div>
      </div>`;
    }).join("");
  },

  _esc(s) { return (s || "").toString().replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c])); },
  _escAttr(s) { return this._esc(s).replace(/"/g, "&quot;"); },

  // Качва всички готови Shorts последователно в YouTube (unlisted, като
  // останалата част от dashboard-а). Продължава към следващия дори ако
  // един качване гръмне, за да не изгуби вече готовите останали.
  async uploadAll() {
    if (!this.items.length) return toast("Няма готови Shorts още");
    if (!Step4.accessToken) return toast("⚠️ Първо влез с Google бутона по-горе");
    const overall = document.getElementById("ssUploadOverallProgress");
    let okCount = 0;
    for (const it of this.items) {
      const statusEl = document.getElementById(`ssItemUploadStatus${it.index}`);
      if (overall) overall.textContent = `⏳ Качвам ${it.index + 1}/${this.items.length}...`;
      const title = document.getElementById(`ssTitle${it.index}`).value || it.title;
      const description = document.getElementById(`ssDesc${it.index}`).value || it.description;
      const tags = document.getElementById(`ssTags${it.index}`).value.split(",").map(s => s.trim()).filter(Boolean);
      const file = new File([it.videoBlob], it.fileName || `short_${it.index + 1}.webm`, { type: "video/webm" });
      try {
        const tempProgId = `ssUploadProgress${it.index}`;
        if (statusEl) statusEl.innerHTML = `<div id="${tempProgId}">⏳ Качвам...</div>`;
        const result = await Step4.uploadVideo(file, { title, description, tags, madeForKids: false }, tempProgId);
        okCount++;
        this.log(`✅ Short ${it.index + 1} качен (unlisted) — Video ID: ${result?.id || "?"}`);
      } catch (e) {
        this.log(`❌ Short ${it.index + 1} — грешка при качване: ${e.message}`);
        if (statusEl) statusEl.innerHTML = `❌ ${e.message}`;
      }
      // Кратка пауза между качванията — по-щадящо към YouTube API квотата.
      await new Promise(r => setTimeout(r, 1200));
    }
    if (overall) overall.textContent = `🎉 Готово — ${okCount}/${this.items.length} Shorts качени успешно.`;
    toast(`Качени ${okCount}/${this.items.length} Shorts`);
  }
};
